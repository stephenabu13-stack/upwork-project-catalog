import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure uploads directory exists for stored designed images and drafts
const UPLOADS_DIR = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Load .env manually without external dependencies
function loadEnv() {
  const envPath = path.join(__dirname, '.env');
  if (!fs.existsSync(envPath)) return {};
  const content = fs.readFileSync(envPath, 'utf-8');
  const env = {};
  for (const line of content.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eqIdx = trimmed.indexOf('=');
    if (eqIdx > 0) {
      const key = trimmed.slice(0, eqIdx).trim();
      const val = trimmed.slice(eqIdx + 1).trim();
      env[key] = val;
    }
  }
  return env;
}

const env = loadEnv();
const PORT = Number(process.env.PORT || env.PORT || 4173);
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || env.GEMINI_API_KEY || '';
const GEMINI_MODEL = process.env.GEMINI_MODEL || env.GEMINI_MODEL || 'gemini-2.5-flash';

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.md': 'text/markdown; charset=utf-8'
};

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  });
  res.end(JSON.stringify(data));
}

function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 25 * 1024 * 1024) { // 25MB limit to support high-res images
        reject(new Error('Request body too large'));
      }
    });
    req.on('end', () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(new Error('Malformed JSON payload'));
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  // CORS Preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
    });
    return res.end();
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // 1. Health check
  if (pathname === '/api/health' && req.method === 'GET') {
    return sendJson(res, 200, {
      status: 'ok',
      version: '1.1.0',
      nodeVersion: process.version,
      geminiConfigured: Boolean(GEMINI_API_KEY && GEMINI_API_KEY.length > 5),
      model: GEMINI_MODEL
    });
  }

  // 2. Active Project Draft (Sync with Extension)
  const projectFilePath = path.join(UPLOADS_DIR, 'active_project.json');

  if (pathname === '/api/project' && req.method === 'GET') {
    if (fs.existsSync(projectFilePath)) {
      try {
        const raw = fs.readFileSync(projectFilePath, 'utf-8');
        return sendJson(res, 200, { success: true, project: JSON.parse(raw) });
      } catch (err) {
        return sendJson(res, 500, { error: 'Failed to read active project: ' + err.message });
      }
    }
    return sendJson(res, 404, { error: 'No active project saved on server yet' });
  }

  if (pathname === '/api/project' && req.method === 'POST') {
    try {
      const payload = await parseJsonBody(req);
      const project = payload.project || payload;
      fs.writeFileSync(projectFilePath, JSON.stringify(project, null, 2), 'utf-8');
      return sendJson(res, 200, { success: true, message: 'Project saved to server for extension sync' });
    } catch (err) {
      return sendJson(res, 500, { error: 'Failed to save project: ' + err.message });
    }
  }

  // 3. Stored Designed Image Endpoints
  const imageMetaPath = path.join(UPLOADS_DIR, 'active_image_meta.json');

  if (pathname === '/api/upload-image' && req.method === 'POST') {
    try {
      const payload = await parseJsonBody(req);
      const fileName = String(payload.fileName || 'designed_cover.png').replace(/[^a-zA-Z0-9._-]/g, '_');
      const dataUrl = payload.dataUrl;

      if (!dataUrl || !dataUrl.includes(',')) {
        return sendJson(res, 400, { error: 'Invalid image dataUrl format' });
      }

      const [header, base64Data] = dataUrl.split(',');
      const mimeMatch = header.match(/data:([^;]+);base64/);
      const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
      const ext = mimeType === 'image/jpeg' ? '.jpg' : '.png';
      const targetFileName = `active_cover${ext}`;
      const targetFilePath = path.join(UPLOADS_DIR, targetFileName);

      const buffer = Buffer.from(base64Data, 'base64');
      fs.writeFileSync(targetFilePath, buffer);

      const meta = {
        exists: true,
        fileName,
        savedFileName: targetFileName,
        mimeType,
        sizeBytes: buffer.length,
        width: Number(payload.width) || 0,
        height: Number(payload.height) || 0,
        aspectRatio: payload.aspectRatio || '4:3',
        updatedAt: new Date().toISOString()
      };
      fs.writeFileSync(imageMetaPath, JSON.stringify(meta, null, 2), 'utf-8');

      return sendJson(res, 200, {
        success: true,
        message: 'Designed image stored successfully on server!',
        meta
      });
    } catch (err) {
      return sendJson(res, 500, { error: 'Failed to upload designed image: ' + err.message });
    }
  }

  if (pathname === '/api/active-image-meta' && req.method === 'GET') {
    if (fs.existsSync(imageMetaPath)) {
      try {
        const raw = fs.readFileSync(imageMetaPath, 'utf-8');
        return sendJson(res, 200, JSON.parse(raw));
      } catch (e) {
        return sendJson(res, 500, { error: e.message });
      }
    }
    return sendJson(res, 200, { exists: false });
  }

  if (pathname === '/api/active-image' && req.method === 'GET') {
    if (fs.existsSync(imageMetaPath)) {
      try {
        const meta = JSON.parse(fs.readFileSync(imageMetaPath, 'utf-8'));
        const imagePath = path.join(UPLOADS_DIR, meta.savedFileName || 'active_cover.png');
        if (fs.existsSync(imagePath)) {
          const stat = fs.statSync(imagePath);
          res.writeHead(200, {
            'Content-Type': meta.mimeType || 'image/png',
            'Content-Length': stat.size,
            'Access-Control-Allow-Origin': '*',
            'Cache-Control': 'no-cache'
          });
          return fs.createReadStream(imagePath).pipe(res);
        }
      } catch (err) {
        return sendJson(res, 500, { error: err.message });
      }
    }
    return sendJson(res, 404, { error: 'No active image stored' });
  }

  // 4. Gemini AI Generation
  if (pathname === '/api/generate' && req.method === 'POST') {
    if (!GEMINI_API_KEY) {
      return sendJson(res, 503, {
        error: 'Gemini API key is not configured.',
        message: 'Add GEMINI_API_KEY to your .env file to enable Gemini AI. Alternatively, use the built-in local template engine which runs 100% offline with zero API key.'
      });
    }

    try {
      const payload = await parseJsonBody(req);
      const niche = payload.niche || 'Brand Identity & Logo Design';
      const brief = payload.brief || '';
      const customKeywords = payload.customKeywords || '';

      const prompt = `You are an expert Upwork Project Catalog copywriter.
Generate an authentic, high-converting, policy-compliant Upwork Project Catalog draft for:
Niche: ${niche}
Deliverables/Brief: ${brief}
Keywords: ${customKeywords}

CRITICAL UPWORK RULES:
1. Title MUST NOT begin with "You will get" (Upwork adds it automatically).
2. Title MUST be at least 7 words and maximum 75 characters.
3. Pricing: Provide 3 tiers (Starter, Standard, Advanced). Tier customTitle max 30 chars, customDesc max 80 chars. Prices between $5 and $500,000.
4. Upwork search tags: exactly 5 tags, each <= 30 chars.
5. Description summary: 120 to 1200 chars. DO NOT include off-platform contacts (no email, phone, WhatsApp, etc.).
6. Requirements: 3 specific questions for buyer onboarding (each 10-250 chars).
7. Steps: 3-4 steps (title <= 60 chars, description <= 250 chars).
8. FAQs: 4 relevant FAQs (question <= 100 chars, answer <= 250 chars).

Return STRICT JSON matching this schema:
{
  "overview": {
    "title": "string (>= 7 words, <= 75 chars, no 'You will get' prefix)",
    "category": "string",
    "searchTags": ["tag1", "tag2", "tag3", "tag4", "tag5"],
    "attributes": { "Style": "string" }
  },
  "pricing": {
    "tierMode": 3,
    "tiers": [
      { "name": "Starter", "customTitle": "string (<=30c)", "customDesc": "string (<=80c)", "deliveryDays": 3, "revisions": 2, "priceUsd": 75, "scopeItems": ["item1", "item2"] },
      { "name": "Standard", "customTitle": "string (<=30c)", "customDesc": "string (<=80c)", "deliveryDays": 5, "revisions": 4, "priceUsd": 175, "scopeItems": ["item1", "item2", "item3"] },
      { "name": "Advanced", "customTitle": "string (<=30c)", "customDesc": "string (<=80c)", "deliveryDays": 7, "revisions": 5, "priceUsd": 350, "scopeItems": ["item1", "item2", "item3", "item4"] }
    ]
  },
  "requirements": {
    "questions": [
      { "question": "string (10-250c)", "answerType": "Free text", "isMandatory": true }
    ]
  },
  "description": {
    "summary": "string (120-1200c)",
    "steps": [
      { "title": "string (<=60c)", "description": "string (<=250c)" }
    ],
    "faqs": [
      { "question": "string (<=100c)", "answer": "string (<=250c)" }
    ]
  }
}`;

      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${GEMINI_API_KEY}`;
      const geminiRes = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: {
            temperature: 0.3,
            responseMimeType: 'application/json'
          }
        })
      });

      if (!geminiRes.ok) {
        const errText = await geminiRes.text();
        return sendJson(res, 502, { error: 'Gemini API error', details: errText });
      }

      const geminiData = await geminiRes.json();
      const rawText = geminiData.candidates?.[0]?.content?.parts?.[0]?.text;
      if (!rawText) {
        return sendJson(res, 500, { error: 'Gemini returned empty response' });
      }

      const parsedResult = JSON.parse(rawText);

      // Clean title if prefix slipped in
      if (parsedResult.overview?.title) {
        parsedResult.overview.title = parsedResult.overview.title
          .replace(/^you\s+will\s+get\s+/i, '')
          .slice(0, 75)
          .trim();
      }

      return sendJson(res, 200, { success: true, data: parsedResult });
    } catch (err) {
      return sendJson(res, 500, { error: 'Failed to process AI generation', message: err.message });
    }
  }

  // 5. Static File Serving
  let relativePath = pathname === '/' ? '/index.html' : pathname;
  // Prevent directory traversal
  const safePath = path.normalize(path.join(__dirname, relativePath));
  if (!safePath.startsWith(__dirname)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    return res.end('Forbidden');
  }

  fs.stat(safePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('File not found: ' + pathname);
    }

    const ext = path.extname(safePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache',
      'X-Content-Type-Options': 'nosniff'
    });

    const stream = fs.createReadStream(safePath);
    stream.pipe(res);
  });
});

server.listen(PORT, () => {
  console.log(`[Upwork Catalog Studio] Running locally at http://localhost:${PORT}`);
  console.log(`[Upwork Catalog Studio] Gemini AI: ${GEMINI_API_KEY ? 'Configured (' + GEMINI_MODEL + ')' : 'Offline / Local templates active'}`);
});

export default server;
