import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import server from '../server.mjs';

after(() => {
  server.close();
});

function get(path) {
  return new Promise((resolve, reject) => {
    const addr = server.address();
    const port = addr ? addr.port : 4173;
    http.get(`http://localhost:${port}${path}`, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    }).on('error', reject);
  });
}

function post(path, payload) {
  return new Promise((resolve, reject) => {
    const addr = server.address();
    const port = addr ? addr.port : 4173;
    const bodyStr = JSON.stringify(payload);
    const req = http.request(`http://localhost:${port}${path}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(bodyStr)
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: data }));
    });
    req.on('error', reject);
    req.write(bodyStr);
    req.end();
  });
}

test('server serves index.html at root', async () => {
  const res = await get('/');
  assert.equal(res.status, 200);
  assert.ok(res.headers['content-type'].includes('text/html'));
  assert.ok(res.body.includes('Upwork Project Catalog Studio'));
});

test('server serves specs/categories.json', async () => {
  const res = await get('/specs/categories.json');
  assert.equal(res.status, 200);
  assert.ok(res.headers['content-type'].includes('application/json'));
  const parsed = JSON.parse(res.body);
  assert.ok(Array.isArray(parsed));
  assert.ok(parsed.length >= 5);
});

test('GET /api/health returns server status and version', async () => {
  const res = await get('/api/health');
  assert.equal(res.status, 200);
  const data = JSON.parse(res.body);
  assert.equal(data.status, 'ok');
  assert.equal(data.version, '1.1.0');
  assert.ok(data.nodeVersion);
});

test('POST /api/project and GET /api/project persist and retrieve active project', async () => {
  const testProject = {
    id: 'test_sync_project',
    name: 'SEO Audit Listing',
    overview: { title: 'a comprehensive technical SEO audit and roadmap' }
  };
  const postRes = await post('/api/project', { project: testProject });
  assert.equal(postRes.status, 200);

  const getRes = await get('/api/project');
  assert.equal(getRes.status, 200);
  const data = JSON.parse(getRes.body);
  assert.equal(data.success, true);
  assert.equal(data.project.name, 'SEO Audit Listing');
});

test('POST /api/upload-image stores designed image and serves via /api/active-image', async () => {
  // 1x1 transparent PNG base64
  const tinyPng = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=';
  const uploadRes = await post('/api/upload-image', {
    fileName: 'my_designed_cover.png',
    dataUrl: tinyPng,
    width: 3600,
    height: 2700,
    aspectRatio: '1.33:1'
  });
  assert.equal(uploadRes.status, 200);
  const uploadData = JSON.parse(uploadRes.body);
  assert.equal(uploadData.success, true);
  assert.equal(uploadData.meta.fileName, 'my_designed_cover.png');

  // Verify metadata
  const metaRes = await get('/api/active-image-meta');
  assert.equal(metaRes.status, 200);
  const metaData = JSON.parse(metaRes.body);
  assert.equal(metaData.exists, true);
  assert.equal(metaData.fileName, 'my_designed_cover.png');
  assert.equal(metaData.width, 3600);

  // Verify binary image served
  const imgRes = await get('/api/active-image');
  assert.equal(imgRes.status, 200);
  assert.ok(imgRes.headers['content-type'].includes('image/png'));
  assert.ok(imgRes.headers['access-control-allow-origin']);
});

test('POST /api/generate without API key returns graceful 503', async () => {
  const res = await post('/api/generate', { niche: 'Logo Design' });
  if (!process.env.GEMINI_API_KEY) {
    assert.equal(res.status, 503);
    const data = JSON.parse(res.body);
    assert.ok(data.error.includes('Gemini API key is not configured'));
  }
});
