import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateOverview,
  validatePricing,
  validateGallery,
  validateRequirements,
  validateDescription,
  validateReview,
  validateDraft,
  validateImportJson,
  countWords,
  LIMITS
} from '../src/validator.js';

test('countWords accurately counts space-separated tokens', () => {
  assert.equal(countWords(''), 0);
  assert.equal(countWords('   '), 0);
  assert.equal(countWords('a b c d e f g'), 7);
  assert.equal(countWords('Wordpress speed optimization for high converting ecommerce'), 7);
});

test('validateOverview enforces Upwork title and tag constraints', () => {
  // Missing title
  let res = validateOverview({ title: '', category: 'Design' });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('Title is required')));

  // Title starting with "You will get"
  res = validateOverview({ title: 'You will get a custom logo design for business', category: 'Design' });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('prefixes "You will get"')));

  // Title under 7 words
  res = validateOverview({ title: 'a modern custom logo design', category: 'Design' });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('at least 7 words')));

  // Title exceeding 75 chars
  const longTitle = 'a modern custom logo design for your growing corporate enterprise and startup business today';
  res = validateOverview({ title: longTitle, category: 'Design' });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('exceeds limit of 75 characters')));

  // Valid Title (>= 7 words, <= 75 chars, no "You will get" prefix)
  const validTitle = 'a modern custom logo design with full vector brand style guidelines';
  res = validateOverview({
    title: validTitle,
    category: 'Design & Creative > Brand Identity Design',
    searchTags: ['logo design', 'branding', 'vector', 'minimalist', 'style guide']
  });
  assert.equal(res.valid, true);
  assert.equal(res.errors.length, 0);

  // Exceeding 5 tags
  res = validateOverview({
    title: validTitle,
    category: 'Design',
    searchTags: ['tag1', 'tag2', 'tag3', 'tag4', 'tag5', 'tag6']
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('at most 5 search tags')));

  // Duplicate tags
  res = validateOverview({
    title: validTitle,
    category: 'Design',
    searchTags: ['logo', 'Logo', 'vector']
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('Duplicate search tag')));
});

test('boundary tests for title, tags, description, requirements, and pricing limits', () => {
  // Title boundary: exactly 75 chars vs 76 chars
  const title75 = 'a'.repeat(9) + ' ' + 'b'.repeat(9) + ' ' + 'c'.repeat(9) + ' ' + 'd'.repeat(9) + ' ' + 'e'.repeat(9) + ' ' + 'f'.repeat(9) + ' ' + 'g'.repeat(15);
  assert.equal(title75.length, 75);
  let res = validateOverview({ title: title75, category: 'Design' });
  assert.equal(res.valid, true, `75 char title should be valid: ${res.errors.join(';')}`);

  const title76 = title75 + 'x';
  res = validateOverview({ title: title76, category: 'Design' });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('exceeds limit of 75 characters')));

  // Tag boundary: 30 chars vs 31 chars
  const tag30 = 't'.repeat(30);
  res = validateOverview({ title: title75, category: 'Design', searchTags: [tag30] });
  assert.equal(res.valid, true);

  const tag31 = 't'.repeat(31);
  res = validateOverview({ title: title75, category: 'Design', searchTags: [tag31] });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('exceeds 30 characters')));

  // Summary boundary: 119 chars vs 120 chars vs 1200 chars vs 1201 chars
  res = validateDescription({ summary: 's'.repeat(119) });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('at least 120 characters')));

  res = validateDescription({ summary: 's'.repeat(120) });
  assert.equal(res.valid, true);

  res = validateDescription({ summary: 's'.repeat(1200) });
  assert.equal(res.valid, true);

  res = validateDescription({ summary: 's'.repeat(1201) });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('exceeds limit of 1200 characters')));

  // Delivery days boundary: 1 and 70 pass, 0 and 71 fail
  res = validatePricing({ tierMode: 1, tiers: [{ name: 'Starter', customTitle: 'T', customDesc: 'D', deliveryDays: 1, priceUsd: 5 }] });
  assert.equal(res.valid, true);

  res = validatePricing({ tierMode: 1, tiers: [{ name: 'Starter', customTitle: 'T', customDesc: 'D', deliveryDays: 70, priceUsd: 500000 }] });
  assert.equal(res.valid, true);

  res = validatePricing({ tierMode: 1, tiers: [{ name: 'Starter', customTitle: 'T', customDesc: 'D', deliveryDays: 71, priceUsd: 5 }] });
  assert.equal(res.valid, false);

  // Price boundary: 5 and 500000 pass, 4 and 500001 fail
  res = validatePricing({ tierMode: 1, tiers: [{ name: 'Starter', customTitle: 'T', customDesc: 'D', deliveryDays: 5, priceUsd: 4 }] });
  assert.equal(res.valid, false);

  res = validatePricing({ tierMode: 1, tiers: [{ name: 'Starter', customTitle: 'T', customDesc: 'D', deliveryDays: 5, priceUsd: 500001 }] });
  assert.equal(res.valid, false);

  // Requirements question boundary: 10 chars vs 9 chars vs 250 chars vs 251 chars
  res = validateRequirements({ questions: [{ question: 'q'.repeat(9) }] });
  assert.equal(res.valid, false);

  res = validateRequirements({ questions: [{ question: 'q'.repeat(10) }] });
  assert.equal(res.valid, true);

  res = validateRequirements({ questions: [{ question: 'q'.repeat(250) }] });
  assert.equal(res.valid, true);

  res = validateRequirements({ questions: [{ question: 'q'.repeat(251) }] });
  assert.equal(res.valid, false);
});

test('validatePricing enforces tier constraints and price bounds', () => {
  // Invalid delivery days & price out of range
  let res = validatePricing({
    tierMode: 1,
    tiers: [
      { name: 'Starter', customTitle: 'Test', customDesc: 'Short desc', deliveryDays: 0, priceUsd: 2 }
    ]
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('Delivery time must be between 1 and 70')));
  assert.ok(res.errors.some(e => e.includes('Price must be between $5 and $500,000')));

  // Custom title exceeding 30 chars
  res = validatePricing({
    tierMode: 1,
    tiers: [
      { name: 'Starter', customTitle: 'This title is definitely way more than thirty characters long', customDesc: 'Desc', deliveryDays: 3, priceUsd: 50 }
    ]
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('Custom title exceeds 30 characters')));

  // Valid 3 tiers
  res = validatePricing({
    tierMode: 3,
    tiers: [
      { name: 'Starter', customTitle: 'Basic', customDesc: 'Core setup', deliveryDays: 2, priceUsd: 50 },
      { name: 'Standard', customTitle: 'Pro', customDesc: 'Standard setup', deliveryDays: 4, priceUsd: 150 },
      { name: 'Advanced', customTitle: 'Enterprise', customDesc: 'Full setup', deliveryDays: 7, priceUsd: 300 }
    ]
  });
  assert.equal(res.valid, true);
  assert.equal(res.errors.length, 0);
});

test('validateGallery checks image, video, and PDF specs', () => {
  // Empty images
  let res = validateGallery({ images: [] });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('At least one project cover image is required')));

  // Image exceeding 10MB
  res = validateGallery({
    images: [{ fileName: 'cover.png', sizeBytes: 11 * 1024 * 1024, width: 3600, height: 2700 }]
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('exceeds 10MB limit')));

  // Image exceeding 4000px
  res = validateGallery({
    images: [{ fileName: 'cover.jpg', sizeBytes: 2 * 1024 * 1024, width: 4500, height: 3000 }]
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('exceeds Upwork 4000px limit')));

  // Valid 3600x2700 image
  res = validateGallery({
    images: [{ fileName: 'cover.png', sizeBytes: 3 * 1024 * 1024, width: 3600, height: 2700 }]
  });
  assert.equal(res.valid, true);
  assert.equal(res.errors.length, 0);

  // Video exceeding 90 seconds
  res = validateGallery({
    images: [{ fileName: 'cover.png', sizeBytes: 1000, width: 1200, height: 900 }],
    videos: [{ fileName: 'intro.mp4', sizeBytes: 10 * 1024 * 1024, durationSeconds: 120 }]
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('must be 90 seconds or less')));

  // PDF exceeding 2MB
  res = validateGallery({
    images: [{ fileName: 'cover.png', sizeBytes: 1000, width: 1200, height: 900 }],
    pdfs: [{ fileName: 'portfolio.pdf', sizeBytes: 3 * 1024 * 1024 }]
  });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('exceeds 2MB limit')));
});

test('validateDescription enforces summary length and detects forbidden contacts', () => {
  // Too short (< 120 chars)
  let res = validateDescription({ summary: 'Too short summary.' });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('at least 120 characters')));

  // Contains forbidden email or phone
  const withEmail = 'We offer great web design. Contact me at user@testmail.com to start your project. We provide high quality results and customer satisfaction.';
  res = validateDescription({ summary: withEmail });
  assert.equal(res.valid, false);
  assert.ok(res.errors.some(e => e.includes('off-platform contact details')));

  // Valid description
  const cleanSummary = 'We deliver modern responsive WordPress websites engineered for blazing speed and high conversion rates. Every project includes mobile optimization, clean semantic code, and full handover walkthroughs.';
  res = validateDescription({
    summary: cleanSummary,
    steps: [{ title: 'Discovery', description: 'Analyze brief and objectives' }],
    faqs: [{ question: 'What is included?', answer: 'Full responsive website build and QA.' }]
  });
  assert.equal(res.valid, true);
  assert.equal(res.errors.length, 0);
});

test('validateImportJson safely rejects malformed or malicious inputs', () => {
  // Malformed JSON syntax
  let res = validateImportJson('{ broken json');
  assert.equal(res.valid, false);

  // Array instead of object
  res = validateImportJson('[1, 2, 3]');
  assert.equal(res.valid, false);

  // Legal checkboxes reset on import
  const fakeDraft = JSON.stringify({
    name: 'Imported',
    review: { copyrightDeclaration: true, termsAgreement: true }
  });
  res = validateImportJson(fakeDraft);
  assert.equal(res.valid, true);
  assert.equal(res.data.review.copyrightDeclaration, false);
  assert.equal(res.data.review.termsAgreement, false);
});

