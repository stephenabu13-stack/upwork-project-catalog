import test from 'node:test';
import assert from 'node:assert/strict';
import { generateLocalDraft, analyzeKeywords, NICHES } from '../src/engine.js';
import { validateOverview, validatePricing, validateDescription } from '../src/validator.js';

test('generateLocalDraft produces valid copy for all supported niches', () => {
  const nicheKeys = Object.keys(NICHES);
  assert.ok(nicheKeys.length >= 5, 'Should have at least 5 supported niches');

  for (const key of nicheKeys) {
    const draft = generateLocalDraft(key);

    // Overview check
    const ovResult = validateOverview(draft.overview);
    assert.equal(ovResult.valid, true, `Niche ${key} overview invalid: ${ovResult.errors.join('; ')}`);
    assert.equal(draft.overview.title.toLowerCase().startsWith('you will get'), false);
    assert.ok(draft.overview.title.length <= 75);

    // Pricing check
    const prResult = validatePricing(draft.pricing);
    assert.equal(prResult.valid, true, `Niche ${key} pricing invalid: ${prResult.errors.join('; ')}`);

    // Description check
    const dsResult = validateDescription(draft.description);
    assert.equal(dsResult.valid, true, `Niche ${key} description invalid: ${dsResult.errors.join('; ')}`);
  }
});

test('analyzeKeywords scores buyer intent and returns top tags', () => {
  const input = `
    hire wordpress developer,
    woocommerce speed optimization,
    what is seo,
    buy custom logo,
    cheap design
  `;

  const report = analyzeKeywords(input);
  assert.ok(report.keywords.length >= 4);
  assert.ok(report.recommendedTags.length > 0);
  assert.ok(report.recommendedTags.length <= 5);

  const topKeyword = report.keywords[0];
  assert.ok(topKeyword.score > 50, 'High intent keyword should have high score');
});

