let activeProject = null;
let activeImageMeta = null;

document.addEventListener('DOMContentLoaded', async () => {
  const statusEl = document.getElementById('projectStatus');
  const imageStatusEl = document.getElementById('imageStatus');
  const btnLoadLocal = document.getElementById('btnLoadLocal');
  const btnAutoFill = document.getElementById('btnAutoFill');
  const btnUploadStoredImage = document.getElementById('btnUploadStoredImage');
  const btnImportJson = document.getElementById('btnImportJson');
  const jsonPaste = document.getElementById('jsonPaste');

  // Load from chrome.storage.local on startup
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['activeCatalogProject', 'activeCoverImage'], (res) => {
      if (res.activeCatalogProject) {
        activeProject = res.activeCatalogProject;
      }
      if (res.activeCoverImage) {
        activeImageMeta = res.activeCoverImage;
      }
      updateStatus();
    });
  }

  // Also try to auto-sync with local server seamlessly
  trySyncLocalStudio(false);

  // Sync with Local Studio button
  btnLoadLocal.addEventListener('click', async () => {
    btnLoadLocal.textContent = 'Syncing with Studio...';
    const ok = await trySyncLocalStudio(true);
    btnLoadLocal.textContent = ok ? '✓ Synced with Studio' : 'Sync with Local Studio';
  });

  async function trySyncLocalStudio(showAlerts = false) {
    try {
      const projRes = await fetch('http://localhost:4173/api/project').catch(() => null);
      if (projRes && projRes.ok) {
        const data = await projRes.json();
        if (data.project) {
          activeProject = data.project;
          chrome.storage.local.set({ activeCatalogProject: activeProject });
        }
      }

      const imgRes = await fetch('http://localhost:4173/api/active-image-meta').catch(() => null);
      if (imgRes && imgRes.ok) {
        const imgData = await imgRes.json();
        if (imgData.exists) {
          activeImageMeta = imgData;
        }
      }

      updateStatus();
      if (showAlerts) {
        if (activeProject) {
          alert(`Successfully synced "${activeProject.name || activeProject.overview?.title}" from Local Studio!`);
        } else {
          alert('Studio is running on http://localhost:4173, but no project has been pushed yet. Click "Push to Extension" in the Studio website!');
        }
      }
      return true;
    } catch (e) {
      if (showAlerts) {
        alert('Could not reach Local Studio at http://localhost:4173.\nEnsure `npm run dev` or `node server.mjs` is running.');
      }
      return false;
    }
  }

  // Import Pasted JSON
  btnImportJson.addEventListener('click', () => {
    const raw = jsonPaste.value.trim();
    if (!raw) return alert('Please paste JSON from Upwork Catalog Studio');
    try {
      const parsed = JSON.parse(raw);
      activeProject = parsed;
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ activeCatalogProject: parsed });
      }
      updateStatus();
      alert('Draft successfully loaded into extension!');
    } catch (err) {
      alert('Invalid JSON: ' + err.message);
    }
  });

  // Auto-Fill Current Step Fields
  btnAutoFill.addEventListener('click', async () => {
    if (!activeProject) {
      await trySyncLocalStudio(false);
    }
    if (!activeProject) {
      return alert('Please load or sync a project draft first!\n(Click "Sync with Local Studio" or "Push to Extension" in the Studio website)');
    }

    const tab = await getActiveUpworkTab();
    if (!tab) return;

    try {
      await sendMessageToTabWithInjection(tab.id, {
        action: 'autoFillStep',
        project: activeProject
      });
    } catch (err) {
      alert('Communication error: ' + err.message);
    }
  });

  // Auto-Upload Stored Designed Image
  btnUploadStoredImage.addEventListener('click', async () => {
    const tab = await getActiveUpworkTab();
    if (!tab) return;

    try {
      await sendMessageToTabWithInjection(tab.id, {
        action: 'autoUploadImage'
      });
    } catch (err) {
      alert('Communication error: ' + err.message);
    }
  });

  // Safe tab communication with auto-injection fallback
  async function sendMessageToTabWithInjection(tabId, message) {
    try {
      return await chrome.tabs.sendMessage(tabId, message);
    } catch (firstErr) {
      // If content script was not already running on this tab, inject dynamically
      try {
        if (chrome.scripting) {
          await chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['content.js']
          });
          await chrome.scripting.insertCSS({
            target: { tabId: tabId },
            files: ['styles.css']
          }).catch(() => {});

          await new Promise(r => setTimeout(r, 200));
          return await chrome.tabs.sendMessage(tabId, message);
        }
      } catch (injectErr) {
        throw new Error('Could not inject content assistant: ' + injectErr.message);
      }
      throw firstErr;
    }
  }

  async function getActiveUpworkTab() {
    if (typeof chrome === 'undefined' || !chrome.tabs) return null;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.url || !tab.url.includes('upwork.com')) {
      alert('Please switch to your open Upwork tab (e.g. upwork.com/nx/project-dashboard/create) before clicking!');
      return null;
    }
    return tab;
  }

  // Quick Copy Buttons
  document.querySelectorAll('[data-copy]').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.dataset.copy;
      if (!activeProject) return alert('Load or paste a project draft first!');

      let text = '';
      if (type === 'title') {
        text = activeProject.overview?.title || '';
      } else if (type === 'tags') {
        text = (activeProject.overview?.searchTags || []).join(', ');
      } else if (type === 'pricing') {
        const pr = activeProject.pricing || {};
        text = (pr.tiers || []).map(t => `${t.name}: $${t.priceUsd} - ${t.customTitle} (${t.deliveryDays}d delivery)`).join('\n');
      } else if (type === 'requirements') {
        text = (activeProject.requirements?.questions || []).map(q => q.question).join('\n\n');
      } else if (type === 'description') {
        text = activeProject.description?.summary || '';
      } else if (type === 'faqs') {
        text = (activeProject.description?.faqs || []).map(f => `Q: ${f.question}\nA: ${f.answer}`).join('\n\n');
      }

      navigator.clipboard.writeText(text).then(() => {
        const orig = btn.textContent;
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = orig, 1200);
      });
    });
  });

  function updateStatus() {
    if (!activeProject) {
      statusEl.textContent = 'No draft loaded yet.';
    } else {
      const title = activeProject.overview?.title || activeProject.name || 'Active Project';
      const tagsCount = (activeProject.overview?.searchTags || []).length;
      statusEl.innerHTML = `<strong>${escapeHtml(title)}</strong><br><span style="color:#5e6d55;font-size:11px;">${tagsCount} tags | ${(activeProject.pricing?.tiers || []).length} tiers</span>`;
    }

    if (activeImageMeta && activeImageMeta.exists) {
      const mb = (activeImageMeta.sizeBytes / (1024 * 1024)).toFixed(1);
      imageStatusEl.innerHTML = `<span style="color:#108a00; font-weight:600;">✓ Designed Image Ready:</span> ${escapeHtml(activeImageMeta.fileName)} (${mb} MB)`;
    } else {
      imageStatusEl.innerHTML = `<span style="color:#94a3b8;">No designed image stored in studio yet.</span>`;
    }
  }

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
  }
});
