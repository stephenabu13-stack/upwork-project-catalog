/**
 * Upwork Project Catalog Floating Content Assistant & Bridge
 * 
 * Works in two contexts:
 * 1. On Localhost Studio (localhost:4173):
 *    Acts as a secure bridge so the web app can directly push drafts and images
 *    into chrome.storage.local with 1-click.
 * 2. On Upwork (upwork.com):
 *    Auto-fills detected fields (Title, tags, tiers, description, requirements)
 *    and automatically uploads your stored designed image into Upwork's gallery!
 */

(function () {
  if (window.__upworkCatalogAssistantInjected) return;
  window.__upworkCatalogAssistantInjected = true;

  const isLocalhost = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

  // =========================================================================
  // Context 1: Localhost Studio Direct Bridge
  // =========================================================================
  if (isLocalhost) {
    // Notify webpage that extension is installed and ready
    window.postMessage({ type: 'UPWORK_EXTENSION_READY', version: '1.1.0' }, '*');

    window.addEventListener('message', (event) => {
      if (!event.data) return;

      if (event.data.type === 'UPWORK_STUDIO_PUSH_PROJECT') {
        const project = event.data.project;
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ activeCatalogProject: project }, () => {
            window.postMessage({ type: 'UPWORK_STUDIO_PUSH_SUCCESS', projectTitle: project.overview?.title || project.name }, '*');
          });
        }
      }

      if (event.data.type === 'UPWORK_STUDIO_PUSH_IMAGE') {
        const imageData = event.data.imageData;
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ activeCoverImage: imageData }, () => {
            window.postMessage({ type: 'UPWORK_STUDIO_IMAGE_SUCCESS' }, '*');
          });
        }
      }
    });

    return; // Don't inject Upwork floating widget on localhost
  }

  // =========================================================================
  // Context 2: Upwork Tab Injected Assistant
  // =========================================================================
  let activeDraft = null;

  // Retrieve cached draft and image metadata from storage
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['activeCatalogProject'], (res) => {
      if (res.activeCatalogProject) {
        activeDraft = res.activeCatalogProject;
        updateWidget();
      }
    });
  }

  // Create floating widget
  const container = document.createElement('div');
  container.id = 'upwork-catalog-floating-assistant';
  container.innerHTML = `
    <div class="ucfa-header" id="ucfaHeader">
      <div class="ucfa-title">
        <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#14a800;"></span>
        Catalog Assistant
      </div>
      <button id="ucfaToggle" style="background:none;border:none;color:#fff;cursor:pointer;font-size:12px;font-weight:bold;">_</button>
    </div>
    <div class="ucfa-body" id="ucfaBody">
      <div id="ucfaStatus" style="margin-bottom:10px;font-weight:500;">No draft loaded.</div>
      <button class="ucfa-btn" id="ucfaFillCurrent">Auto-Fill Current Step Fields</button>
      <button class="ucfa-btn" id="ucfaUploadImage" style="background:#0284c7;">Auto-Upload Stored Image</button>
      <div class="ucfa-tip" id="ucfaTip">
        <strong>Auto-Fill Active:</strong> Works on Overview, Pricing, Gallery, Requirements &amp; Description steps.
      </div>
    </div>
  `;
  document.body.appendChild(container);

  const body = container.querySelector('#ucfaBody');
  const toggleBtn = container.querySelector('#ucfaToggle');
  const fillBtn = container.querySelector('#ucfaFillCurrent');
  const uploadImgBtn = container.querySelector('#ucfaUploadImage');
  const statusEl = container.querySelector('#ucfaStatus');

  let isCollapsed = false;
  toggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    isCollapsed = !isCollapsed;
    body.style.display = isCollapsed ? 'none' : 'block';
    toggleBtn.textContent = isCollapsed ? '+' : '_';
    container.classList.toggle('minimized', isCollapsed);
  });

  fillBtn.addEventListener('click', async () => {
    if (!activeDraft) {
      await refreshDraftFromLocalServer();
    }
    if (!activeDraft) {
      alert('No catalog draft loaded! Please open Upwork Catalog Studio (http://localhost:4173) and click "Push to Extension" or load JSON in the popup.');
      return;
    }
    executeAutoFill(activeDraft);
  });

  uploadImgBtn.addEventListener('click', async () => {
    await autoUploadDesignedImage();
  });

  function updateWidget() {
    if (!activeDraft) {
      statusEl.textContent = 'No draft loaded.';
      return;
    }
    const title = activeDraft.overview?.title || activeDraft.name || 'Catalog Draft';
    statusEl.innerHTML = `<span style="color:#108a00;font-weight:600;">Draft Ready:</span><br>${escapeHtml(title).slice(0, 48)}...`;
  }

  async function refreshDraftFromLocalServer() {
    try {
      const res = await fetch('http://localhost:4173/api/project');
      if (res.ok) {
        const data = await res.json();
        if (data.project) {
          activeDraft = data.project;
          chrome.storage.local.set({ activeCatalogProject: activeDraft });
          updateWidget();
        }
      }
    } catch (e) {
      // Server not reachable
    }
  }

  // =========================================================================
  // Core Automation: Auto-Fill Step Fields
  // =========================================================================
  async function executeAutoFill(project) {
    let filledActions = [];

    // 1. Overview Step: Title
    // Upwork project catalog title input usually has placeholder "a fantastic deliverable that drives impact"
    const titleInput = document.querySelector(
      'input[placeholder*="fantastic deliverable" i], input[aria-label*="title" i], input[placeholder*="title" i], input[name*="title" i], textarea[placeholder*="fantastic deliverable" i], textarea[aria-label*="title" i]'
    );
    if (titleInput && project.overview?.title) {
      const cleanTitle = project.overview.title.replace(/^you\s+will\s+get\s+/i, '');
      setNativeInputValue(titleInput, cleanTitle);
      filledActions.push('Project Title');
    }

    // 2. Overview Step: Search Tags
    const tagInput = document.querySelector(
      'input[placeholder*="tag" i], input[aria-label*="tag" i], input[id*="tag" i], .air3-token-input input'
    );
    if (tagInput && Array.isArray(project.overview?.searchTags) && project.overview.searchTags.length > 0) {
      for (const tag of project.overview.searchTags) {
        setNativeInputValue(tagInput, tag);
        tagInput.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        tagInput.dispatchEvent(new KeyboardEvent('keypress', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        tagInput.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
        await sleep(150);
      }
      filledActions.push(`${project.overview.searchTags.length} Search Tags`);
    }

    // 3. Gallery Step: Auto-upload stored designed image
    const isGalleryStep = Boolean(
      document.querySelector('input[type="file"][accept*="image" i]') ||
      document.querySelector('[data-qa*="gallery" i], [data-qa*="dropzone" i], .up-file-upload')
    );
    if (isGalleryStep) {
      const ok = await autoUploadDesignedImage();
      if (ok) filledActions.push('Uploaded Stored Cover Image');
    }

    // 4. Description Step: Project Summary textarea
    const descTextarea = document.querySelector(
      'textarea[aria-label*="description" i], textarea[placeholder*="description" i], textarea[name*="description" i], div[contenteditable="true"]'
    );
    if (descTextarea && project.description?.summary) {
      if (descTextarea.getAttribute('contenteditable') === 'true') {
        descTextarea.innerText = project.description.summary;
        descTextarea.dispatchEvent(new Event('input', { bubbles: true }));
      } else {
        setNativeInputValue(descTextarea, project.description.summary);
      }
      filledActions.push('Project Summary Description');
    }

    // 5. Pricing Step: Custom titles and descriptions
    const tierInputs = document.querySelectorAll('input[name*="title" i], input[aria-label*="tier" i], input[placeholder*="Custom title" i]');
    if (tierInputs.length > 0 && project.pricing?.tiers) {
      tierInputs.forEach((inp, idx) => {
        const tier = project.pricing.tiers[idx];
        if (tier?.customTitle) {
          setNativeInputValue(inp, tier.customTitle);
        }
      });
      filledActions.push('Pricing Tier Fields');
    }

    // 6. Requirements Step: Questions
    const reqInputs = document.querySelectorAll('textarea[aria-label*="requirement" i], textarea[placeholder*="requirement" i], textarea[aria-label*="question" i]');
    if (reqInputs.length > 0 && project.requirements?.questions) {
      reqInputs.forEach((inp, idx) => {
        const q = project.requirements.questions[idx];
        if (q?.question) {
          setNativeInputValue(inp, q.question);
        }
      });
      filledActions.push('Requirement Questions');
    }

    if (filledActions.length > 0) {
      alert(`Auto-filled detected step elements:\n• ${filledActions.join('\n• ')}`);
    } else {
      alert('Could not locate recognized input fields on this step.\nTip: You can use the extension popup to copy any field with 1 click!');
    }
  }

  // =========================================================================
  // Core Automation: Auto-Upload Stored Designed Image into Upwork
  // =========================================================================
  async function autoUploadDesignedImage() {
    let blob = null;
    let fileName = 'designed_cover.png';

    // Priority 1: Fetch active image from Local Studio Server
    try {
      const res = await fetch('http://localhost:4173/api/active-image');
      if (res.ok) {
        blob = await res.blob();
        const metaRes = await fetch('http://localhost:4173/api/active-image-meta').catch(() => null);
        if (metaRes && metaRes.ok) {
          const meta = await metaRes.json();
          if (meta.fileName) fileName = meta.fileName;
        }
      }
    } catch (e) {
      console.warn('Could not fetch active image from localhost:4173');
    }

    // Priority 2: Fetch active image from chrome.storage.local
    if (!blob) {
      const stored = await new Promise(r => chrome.storage.local.get(['activeCoverImage'], r));
      if (stored.activeCoverImage && stored.activeCoverImage.dataUrl) {
        const resp = await fetch(stored.activeCoverImage.dataUrl);
        blob = await resp.blob();
        fileName = stored.activeCoverImage.fileName || 'designed_cover.png';
      }
    }

    if (!blob) {
      alert('No designed image found in storage!\n\nPlease open Upwork Catalog Studio at http://localhost:4173, go to Step 3 (Gallery), and drop your designed image into the "Stored Designed Image" box first.');
      return false;
    }

    const file = new File([blob], fileName, { type: blob.type || 'image/png' });

    // Locate Upwork file input & dropzone
    const fileInput = document.querySelector('input[type="file"][accept*="image" i], input[type="file"]');
    const dropzone = document.querySelector('[data-qa*="dropzone" i], .up-file-upload, [class*="dropzone" i], [class*="upload" i], [aria-label*="gallery" i]');

    let uploaded = false;

    if (fileInput) {
      const dt = new DataTransfer();
      dt.items.add(file);
      fileInput.files = dt.files;
      fileInput.dispatchEvent(new Event('input', { bubbles: true }));
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));
      flashElement(fileInput, '#108a00');
      uploaded = true;
    }

    if (dropzone) {
      const dt = new DataTransfer();
      dt.items.add(file);
      dropzone.dispatchEvent(new DragEvent('dragenter', { bubbles: true, cancelable: true, dataTransfer: dt }));
      dropzone.dispatchEvent(new DragEvent('dragover', { bubbles: true, cancelable: true, dataTransfer: dt }));
      dropzone.dispatchEvent(new DragEvent('drop', { bubbles: true, cancelable: true, dataTransfer: dt }));
      flashElement(dropzone, '#108a00');
      uploaded = true;
    }

    if (uploaded) {
      alert(`✓ Stored designed image "${fileName}" automatically dispatched to Upwork Gallery! Check the progress bar.`);
      return true;
    } else {
      alert('Could not find Upwork image upload field on this page. Please ensure you are currently on Step 3 (Gallery) of Project Catalog creation.');
      return false;
    }
  }

  // =========================================================================
  // DOM Input Helper Utilities
  // =========================================================================
  function setNativeInputValue(element, value) {
    const valueSetter = Object.getOwnPropertyDescriptor(element, 'value')?.set;
    const prototype = Object.getPrototypeOf(element);
    const prototypeValueSetter = Object.getOwnPropertyDescriptor(prototype, 'value')?.set;

    if (prototypeValueSetter && valueSetter !== prototypeValueSetter) {
      prototypeValueSetter.call(element, value);
    } else if (valueSetter) {
      valueSetter.call(element, value);
    } else {
      element.value = value;
    }

    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
    flashElement(element);
  }

  function flashElement(el, color = '#108a00') {
    if (!el) return;
    const origTransition = el.style.transition;
    const origOutline = el.style.outline;
    el.style.transition = 'outline 0.3s ease';
    el.style.outline = `3px solid ${color}`;
    setTimeout(() => {
      el.style.outline = origOutline;
      el.style.transition = origTransition;
    }, 1500);
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
  }

  // Listen for messages from popup
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
      if (req.action === 'autoFillStep') {
        activeDraft = req.project;
        updateWidget();
        executeAutoFill(req.project).then(() => {
          sendResponse({ success: true, message: 'Step content processed!' });
        });
        return true; // async sendResponse
      }

      if (req.action === 'autoUploadImage') {
        autoUploadDesignedImage().then((ok) => {
          sendResponse({ success: ok });
        });
        return true;
      }

      if (req.action === 'ping') {
        sendResponse({ pong: true, version: '1.1.0' });
        return true;
      }
    });
  }
})();
