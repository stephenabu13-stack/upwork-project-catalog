/**
 * Upwork Project Catalog Validation Suite
 * Strictly enforces official Upwork constraints based on /specs/limits.json
 */

export const LIMITS = {
  titlePrefix: "You will get",
  titleMaxChars: 75,
  titleMinWords: 7,
  maxTags: 5,
  tagMaxChars: 30,
  tierModes: [1, 3],
  customTitleMaxChars: 30,
  customDescMaxChars: 80,
  minDeliveryDays: 1,
  maxDeliveryDays: 70,
  minPriceUsd: 5,
  maxPriceUsd: 500000,
  maxImages: 20,
  maxImageSizeBytes: 10 * 1024 * 1024, // 10MB
  maxImageDimensionPx: 4000,
  maxVideos: 1,
  maxVideoSizeBytes: 100 * 1024 * 1024, // 100MB
  maxVideoDurationSeconds: 90,
  maxPdfs: 2,
  maxPdfSizeBytes: 2 * 1024 * 1024, // 2MB
  minQuestions: 1,
  maxQuestions: 20,
  questionMinChars: 10,
  questionMaxChars: 250,
  summaryMinChars: 120,
  summaryMaxChars: 1200,
  maxSteps: 10,
  stepTitleMaxChars: 60,
  stepDescMaxChars: 250,
  maxFaqs: 5,
  faqQuestionMaxChars: 100,
  faqAnswerMaxChars: 250,
  maxSimultaneousProjects: 20
};

// Forbidden off-platform contact patterns (Upwork Terms of Service compliance)
const OFF_PLATFORM_PATTERNS = [
  /(\bwhatsapp\b|\btelegram\b|\bskype\b|\bdiscord\b|\bzoom\b)/i,
  /(\bemail\b|\bmail\b|\bgmail\b|\byahoo\b).{0,15}[:=].{0,15}[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i,
  /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i,
  /(\bcall\s+me\b|\bphone\b|\btext\s+me\b|\bwhatsapp\s+me\b).{0,15}\+?[0-9]{7,15}/i
];

export function countWords(str) {
  if (!str || typeof str !== 'string') return 0;
  const tokens = str.trim().split(/\s+/).filter(Boolean);
  return tokens.length;
}

export function validateOverview(overview = {}) {
  const errors = [];
  const warnings = [];

  const rawTitle = (overview.title || '').trim();
  if (!rawTitle) {
    errors.push('Title is required.');
  } else {
    // Check if user erroneously started title with "You will get"
    if (/^you\s+will\s+get\b/i.test(rawTitle)) {
      errors.push('Upwork automatically prefixes "You will get" to your title. Remove "You will get" from the beginning.');
    }

    if (rawTitle.length > LIMITS.titleMaxChars) {
      errors.push(`Title exceeds limit of ${LIMITS.titleMaxChars} characters (currently ${rawTitle.length}).`);
    }

    const words = countWords(rawTitle);
    if (words < LIMITS.titleMinWords) {
      errors.push(`Title must be at least ${LIMITS.titleMinWords} words (currently ${words} words).`);
    }
  }

  if (!overview.category) {
    errors.push('Category selection is required.');
  }

  const tags = Array.isArray(overview.searchTags) ? overview.searchTags : [];
  if (tags.length > LIMITS.maxTags) {
    errors.push(`Upwork permits at most ${LIMITS.maxTags} search tags (currently ${tags.length}).`);
  }
  if (tags.length === 0) {
    warnings.push('Adding 3 to 5 search tags is highly recommended for Upwork search discoverability.');
  }

  const seenTags = new Set();
  tags.forEach((tag, idx) => {
    const trimmed = String(tag || '').trim();
    if (!trimmed) {
      errors.push(`Search tag #${idx + 1} cannot be empty.`);
    } else if (trimmed.length > LIMITS.tagMaxChars) {
      errors.push(`Search tag "${trimmed}" exceeds ${LIMITS.tagMaxChars} characters.`);
    } else if (seenTags.has(trimmed.toLowerCase())) {
      errors.push(`Duplicate search tag: "${trimmed}".`);
    } else {
      seenTags.add(trimmed.toLowerCase());
    }
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export function validatePricing(pricing = {}) {
  const errors = [];
  const warnings = [];

  const tierMode = Number(pricing.tierMode) || 3;
  if (!LIMITS.tierModes.includes(tierMode)) {
    errors.push(`Tier mode must be either 1 or 3 tiers.`);
  }

  const tiers = Array.isArray(pricing.tiers) ? pricing.tiers : [];
  if (tiers.length < tierMode) {
    errors.push(`Pricing requires ${tierMode} configured tier(s), but found ${tiers.length}.`);
  }

  const activeTiers = tiers.slice(0, tierMode);

  activeTiers.forEach((tier, idx) => {
    const tierName = tier.name || `Tier ${idx + 1}`;
    const customTitle = (tier.customTitle || '').trim();
    const customDesc = (tier.customDesc || '').trim();
    const deliveryDays = Number(tier.deliveryDays);
    const priceUsd = Number(tier.priceUsd);

    if (!customTitle) {
      errors.push(`${tierName}: Custom title is required.`);
    } else if (customTitle.length > LIMITS.customTitleMaxChars) {
      errors.push(`${tierName}: Custom title exceeds ${LIMITS.customTitleMaxChars} characters (currently ${customTitle.length}).`);
    }

    if (!customDesc) {
      errors.push(`${tierName}: Custom description is required.`);
    } else if (customDesc.length > LIMITS.customDescMaxChars) {
      errors.push(`${tierName}: Custom description exceeds ${LIMITS.customDescMaxChars} characters (currently ${customDesc.length}).`);
    }

    if (isNaN(deliveryDays) || deliveryDays < LIMITS.minDeliveryDays || deliveryDays > LIMITS.maxDeliveryDays) {
      errors.push(`${tierName}: Delivery time must be between ${LIMITS.minDeliveryDays} and ${LIMITS.maxDeliveryDays} days.`);
    }

    if (isNaN(priceUsd) || priceUsd < LIMITS.minPriceUsd || priceUsd > LIMITS.maxPriceUsd) {
      errors.push(`${tierName}: Price must be between $${LIMITS.minPriceUsd} and $${LIMITS.maxPriceUsd.toLocaleString()} USD.`);
    }
  });

  // Check 3-tier value ladder consistency
  if (tierMode === 3 && activeTiers.length === 3) {
    const [starter, standard, advanced] = activeTiers;
    const p1 = Number(starter.priceUsd) || 0;
    const p2 = Number(standard.priceUsd) || 0;
    const p3 = Number(advanced.priceUsd) || 0;

    if (p1 > p2) {
      warnings.push(`Starter price ($${p1}) is higher than Standard price ($${p2}). Pricing ladder usually scales upward.`);
    }
    if (p2 > p3) {
      warnings.push(`Standard price ($${p2}) is higher than Advanced price ($${p3}). Pricing ladder usually scales upward.`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export function validateGallery(gallery = {}) {
  const errors = [];
  const warnings = [];

  const images = Array.isArray(gallery.images) ? gallery.images : [];

  if (images.length === 0) {
    errors.push('At least one project cover image is required for an Upwork Project Catalog.');
  } else if (images.length > LIMITS.maxImages) {
    errors.push(`Maximum of ${LIMITS.maxImages} images allowed (currently ${images.length}).`);
  }

  images.forEach((img, idx) => {
    const label = img.fileName || `Image #${idx + 1}`;
    const ext = (img.fileName ? img.fileName.split('.').pop() : '').toLowerCase();

    if (ext && !['jpg', 'jpeg', 'png'].includes(ext)) {
      errors.push(`${label}: Unsupported format ".${ext}". Upwork requires JPG or PNG.`);
    }

    if (img.sizeBytes && img.sizeBytes > LIMITS.maxImageSizeBytes) {
      const mb = (img.sizeBytes / (1024 * 1024)).toFixed(1);
      errors.push(`${label}: File size exceeds 10MB limit (currently ${mb} MB).`);
    }

    if (img.width && img.width > LIMITS.maxImageDimensionPx) {
      errors.push(`${label}: Width (${img.width}px) exceeds Upwork 4000px limit.`);
    }
    if (img.height && img.height > LIMITS.maxImageDimensionPx) {
      errors.push(`${label}: Height (${img.height}px) exceeds Upwork 4000px limit.`);
    }

    if (img.width && img.height) {
      const ratio = img.width / img.height;
      // 4:3 is ~1.333
      if (ratio < 1.2 || ratio > 1.45) {
        warnings.push(`${label}: Aspect ratio is ${(ratio).toFixed(2)}:1. Upwork recommends 4:3 (e.g., 3600×2700 or 1200×900) to avoid awkward cropping in search grids.`);
      }
    }
  });

  const videos = Array.isArray(gallery.videos) ? gallery.videos : [];
  if (videos.length > LIMITS.maxVideos) {
    errors.push(`Upwork allows at most ${LIMITS.maxVideos} video sample.`);
  }
  videos.forEach((vid, idx) => {
    const label = vid.fileName || `Video #${idx + 1}`;
    const ext = (vid.fileName ? vid.fileName.split('.').pop() : '').toLowerCase();
    if (ext && ext !== 'mp4') {
      errors.push(`${label}: Only MP4 video files are accepted by Upwork.`);
    }
    if (vid.sizeBytes && vid.sizeBytes > LIMITS.maxVideoSizeBytes) {
      const mb = (vid.sizeBytes / (1024 * 1024)).toFixed(1);
      errors.push(`${label}: Video size exceeds 100MB limit (currently ${mb} MB).`);
    }
    if (vid.durationSeconds && vid.durationSeconds > LIMITS.maxVideoDurationSeconds) {
      errors.push(`${label}: Video duration must be 90 seconds or less (currently ${vid.durationSeconds}s).`);
    }
  });

  const pdfs = Array.isArray(gallery.pdfs) ? gallery.pdfs : [];
  if (pdfs.length > LIMITS.maxPdfs) {
    errors.push(`Upwork allows at most ${LIMITS.maxPdfs} PDF documents.`);
  }
  pdfs.forEach((pdf, idx) => {
    const label = pdf.fileName || `PDF #${idx + 1}`;
    const ext = (pdf.fileName ? pdf.fileName.split('.').pop() : '').toLowerCase();
    if (ext && ext !== 'pdf') {
      errors.push(`${label}: File must be a PDF document.`);
    }
    if (pdf.sizeBytes && pdf.sizeBytes > LIMITS.maxPdfSizeBytes) {
      const mb = (pdf.sizeBytes / (1024 * 1024)).toFixed(2);
      errors.push(`${label}: PDF exceeds 2MB limit (currently ${mb} MB).`);
    }
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export function validateRequirements(requirements = {}) {
  const errors = [];
  const warnings = [];

  const questions = Array.isArray(requirements.questions) ? requirements.questions : [];

  if (questions.length < LIMITS.minQuestions) {
    errors.push(`At least ${LIMITS.minQuestions} requirement question is required so buyers can provide project inputs.`);
  }
  if (questions.length > LIMITS.maxQuestions) {
    errors.push(`Maximum of ${LIMITS.maxQuestions} requirement questions allowed.`);
  }

  questions.forEach((q, idx) => {
    const text = (q.question || '').trim();
    if (!text) {
      errors.push(`Requirement #${idx + 1}: Question text cannot be empty.`);
    } else {
      if (text.length < LIMITS.questionMinChars) {
        errors.push(`Requirement #${idx + 1}: Must be at least ${LIMITS.questionMinChars} characters (currently ${text.length}).`);
      }
      if (text.length > LIMITS.questionMaxChars) {
        errors.push(`Requirement #${idx + 1}: Exceeds limit of ${LIMITS.questionMaxChars} characters (currently ${text.length}).`);
      }
    }
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export function validateDescription(description = {}) {
  const errors = [];
  const warnings = [];

  const summary = (description.summary || '').trim();

  if (!summary) {
    errors.push('Project summary description is required.');
  } else {
    if (summary.length < LIMITS.summaryMinChars) {
      errors.push(`Project summary must be at least ${LIMITS.summaryMinChars} characters (currently ${summary.length}).`);
    }
    if (summary.length > LIMITS.summaryMaxChars) {
      errors.push(`Project summary exceeds limit of ${LIMITS.summaryMaxChars} characters (currently ${summary.length}).`);
    }

    // Policy check for off-platform contact
    for (const pat of OFF_PLATFORM_PATTERNS) {
      if (pat.test(summary)) {
        errors.push('Project summary appears to contain off-platform contact details (email/phone/WhatsApp/Skype), which violates Upwork Terms of Service and will cause catalog rejection.');
        break;
      }
    }

    // Unrealistic guarantees check
    if (/(100%\s+guarantee|guaranteed\s+(#1|first\s+page)|unlimited\s+money\s+back)/i.test(summary)) {
      warnings.push('Avoid extreme promises ("100% guarantee", "guaranteed #1 ranking") as Upwork reviewers frequently flag them as misleading.');
    }
  }

  const steps = Array.isArray(description.steps) ? description.steps : [];
  if (steps.length > LIMITS.maxSteps) {
    errors.push(`Maximum of ${LIMITS.maxSteps} project steps allowed.`);
  }
  steps.forEach((step, idx) => {
    const title = (step.title || '').trim();
    const desc = (step.description || '').trim();

    if (title.length > LIMITS.stepTitleMaxChars) {
      errors.push(`Step #${idx + 1} title exceeds ${LIMITS.stepTitleMaxChars} characters (currently ${title.length}).`);
    }
    if (desc && desc.length > LIMITS.stepDescMaxChars) {
      errors.push(`Step #${idx + 1} description exceeds ${LIMITS.stepDescMaxChars} characters (currently ${desc.length}).`);
    }
  });

  const faqs = Array.isArray(description.faqs) ? description.faqs : [];
  if (faqs.length > LIMITS.maxFaqs) {
    errors.push(`Upwork allows at most ${LIMITS.maxFaqs} FAQs (currently ${faqs.length}).`);
  }
  faqs.forEach((faq, idx) => {
    const q = (faq.question || '').trim();
    const a = (faq.answer || '').trim();

    if (!q) {
      errors.push(`FAQ #${idx + 1}: Question cannot be empty.`);
    } else if (q.length > LIMITS.faqQuestionMaxChars) {
      errors.push(`FAQ #${idx + 1}: Question exceeds ${LIMITS.faqQuestionMaxChars} characters.`);
    }

    if (!a) {
      errors.push(`FAQ #${idx + 1}: Answer cannot be empty.`);
    } else if (a.length > LIMITS.faqAnswerMaxChars) {
      errors.push(`FAQ #${idx + 1}: Answer exceeds ${LIMITS.faqAnswerMaxChars} characters.`);
    }
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export function validateReview(review = {}) {
  const errors = [];
  const warnings = [];

  if (!review.copyrightDeclaration) {
    errors.push('You must confirm that you hold all necessary rights and licenses for this project work.');
  }
  if (!review.termsAgreement) {
    errors.push('You must agree to the Upwork Terms of Service before publishing.');
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings
  };
}

export function validateDraft(draft = {}) {
  const overviewResult = validateOverview(draft.overview);
  const pricingResult = validatePricing(draft.pricing);
  const galleryResult = validateGallery(draft.gallery);
  const requirementsResult = validateRequirements(draft.requirements);
  const descriptionResult = validateDescription(draft.description);
  const reviewResult = validateReview(draft.review);

  const allErrors = [
    ...overviewResult.errors.map(e => `[Overview] ${e}`),
    ...pricingResult.errors.map(e => `[Pricing] ${e}`),
    ...galleryResult.errors.map(e => `[Gallery] ${e}`),
    ...requirementsResult.errors.map(e => `[Requirements] ${e}`),
    ...descriptionResult.errors.map(e => `[Description] ${e}`),
    ...reviewResult.errors.map(e => `[Review] ${e}`)
  ];

  const allWarnings = [
    ...overviewResult.warnings.map(w => `[Overview] ${w}`),
    ...pricingResult.warnings.map(w => `[Pricing] ${w}`),
    ...galleryResult.warnings.map(w => `[Gallery] ${w}`),
    ...requirementsResult.warnings.map(w => `[Requirements] ${w}`),
    ...descriptionResult.warnings.map(w => `[Description] ${w}`),
    ...reviewResult.warnings.map(w => `[Review] ${w}`)
  ];

  return {
    valid: allErrors.length === 0,
    errors: allErrors,
    warnings: allWarnings,
    sections: {
      overview: overviewResult,
      pricing: pricingResult,
      gallery: galleryResult,
      requirements: requirementsResult,
      description: descriptionResult,
      review: reviewResult
    }
  };
}

export function validateImportJson(rawInput) {
  let parsed;
  try {
    parsed = typeof rawInput === 'string' ? JSON.parse(rawInput) : rawInput;
  } catch (err) {
    return { valid: false, error: `Invalid JSON syntax: ${err.message}` };
  }

  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { valid: false, error: 'Import payload must be a JSON object.' };
  }

  // Ensure minimum structure exists
  const sanitized = {
    id: typeof parsed.id === 'string' ? parsed.id : `draft_${Date.now()}`,
    name: typeof parsed.name === 'string' ? parsed.name : 'Imported Project',
    updatedAt: new Date().toISOString(),
    overview: parsed.overview && typeof parsed.overview === 'object' ? parsed.overview : {},
    pricing: parsed.pricing && typeof parsed.pricing === 'object' ? parsed.pricing : {},
    gallery: parsed.gallery && typeof parsed.gallery === 'object' ? parsed.gallery : { images: [], videos: [], pdfs: [] },
    requirements: parsed.requirements && typeof parsed.requirements === 'object' ? parsed.requirements : { questions: [] },
    description: parsed.description && typeof parsed.description === 'object' ? parsed.description : { steps: [], faqs: [] },
    // Legal checkboxes are NEVER trusted or imported as true
    review: {
      copyrightDeclaration: false,
      termsAgreement: false
    }
  };

  // Strip any accidental binary data from gallery
  if (Array.isArray(sanitized.gallery.images)) {
    sanitized.gallery.images = sanitized.gallery.images.map(img => ({
      fileName: String(img.fileName || 'image.png'),
      sizeBytes: Number(img.sizeBytes) || 0,
      width: Number(img.width) || 0,
      height: Number(img.height) || 0,
      status: img.status || 'valid'
    }));
  }

  return { valid: true, data: sanitized };
}

