/**
 * Safe LocalStorage Management for Upwork Project Catalog Studio
 * Enforces schema guards, strips binary media bytes, and supports import/export.
 */

import { validateImportJson } from './validator.js';

const STORAGE_KEY = 'upwork_catalog_studio_projects';
const ACTIVE_ID_KEY = 'upwork_catalog_studio_active_id';

export function getAllProjects() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const list = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch (err) {
    console.error('Failed to read projects from localStorage:', err);
    return [];
  }
}

export function saveAllProjects(projects) {
  try {
    // Sanitize every project before writing
    const safeList = projects.map(p => sanitizeForStorage(p));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(safeList));
    return true;
  } catch (err) {
    console.error('Failed to save projects to localStorage:', err);
    return false;
  }
}

export function getProject(id) {
  const all = getAllProjects();
  return all.find(p => p.id === id) || null;
}

export function getActiveProjectId() {
  return localStorage.getItem(ACTIVE_ID_KEY) || null;
}

export function setActiveProjectId(id) {
  if (id) {
    localStorage.setItem(ACTIVE_ID_KEY, id);
  } else {
    localStorage.removeItem(ACTIVE_ID_KEY);
  }
}

export function saveProject(project) {
  if (!project || !project.id) return false;
  const all = getAllProjects();
  const idx = all.findIndex(p => p.id === project.id);
  const updated = {
    ...project,
    updatedAt: new Date().toISOString()
  };

  if (idx >= 0) {
    all[idx] = updated;
  } else {
    all.unshift(updated);
  }

  const ok = saveAllProjects(all);
  if (ok) {
    setActiveProjectId(updated.id);
  }
  return ok;
}

export function duplicateProject(id) {
  const project = getProject(id);
  if (!project) return null;

  const copy = JSON.parse(JSON.stringify(project));
  copy.id = `draft_${Date.now()}`;
  copy.name = `${project.name || 'Project'} (Copy)`;
  copy.updatedAt = new Date().toISOString();

  // Reset legal declaration flags on duplicated project
  if (copy.review) {
    copy.review.copyrightDeclaration = false;
    copy.review.termsAgreement = false;
  }

  saveProject(copy);
  return copy;
}

export function deleteProject(id) {
  const all = getAllProjects();
  const filtered = all.filter(p => p.id !== id);
  saveAllProjects(filtered);

  if (getActiveProjectId() === id) {
    const next = filtered[0];
    setActiveProjectId(next ? next.id : null);
  }
  return filtered;
}

export function createNewProject(name = 'New Project Catalog') {
  const newProj = {
    id: `draft_${Date.now()}`,
    name,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    overview: {
      title: '',
      category: '',
      categorySlug: '',
      searchTags: [],
      attributes: {}
    },
    pricing: {
      tierMode: 3,
      tiers: [
        { name: 'Starter', customTitle: 'Basic Setup', customDesc: 'Core essential deliverable with standard delivery', deliveryDays: 3, revisions: 1, priceUsd: 50, scopeItems: [] },
        { name: 'Standard', customTitle: 'Professional Package', customDesc: 'Complete solution including standard deliverables and source files', deliveryDays: 5, revisions: 2, priceUsd: 150, scopeItems: [] },
        { name: 'Advanced', customTitle: 'Enterprise Suite', customDesc: 'Full comprehensive execution with priority turnaround and strategy', deliveryDays: 7, revisions: 3, priceUsd: 300, scopeItems: [] }
      ]
    },
    gallery: {
      images: [],
      videos: [],
      pdfs: []
    },
    requirements: {
      questions: [
        { question: 'Please share your brand name, core goals, and any relevant reference links or materials.', answerType: 'Free text', isMandatory: true }
      ]
    },
    description: {
      summary: '',
      steps: [
        { title: 'Discovery & Brief Review', description: 'Analyze your inputs, target audience, and project specifications.' },
        { title: 'Design & Development', description: 'Craft the initial drafts and deliverable components according to specs.' },
        { title: 'Revisions & Final Polish', description: 'Incorporate your feedback and deliver all final production assets.' }
      ],
      faqs: []
    },
    review: {
      copyrightDeclaration: false,
      termsAgreement: false
    }
  };

  saveProject(newProj);
  return newProj;
}

/**
 * Strips raw binary / base64 bytes to keep localStorage safe and fast
 */
function sanitizeForStorage(project) {
  if (!project) return null;
  const clone = JSON.parse(JSON.stringify(project));

  if (clone.gallery && Array.isArray(clone.gallery.images)) {
    clone.gallery.images = clone.gallery.images.map(img => ({
      fileName: String(img.fileName || 'image.png'),
      sizeBytes: Number(img.sizeBytes) || 0,
      width: Number(img.width) || 0,
      height: Number(img.height) || 0,
      uploadedAt: img.uploadedAt || new Date().toISOString()
    }));
  }

  // Never store base64 in draft
  delete clone.coverDataUrl;
  return clone;
}

export function exportProjectAsJson(project) {
  const sanitized = sanitizeForStorage(project);
  return JSON.stringify(sanitized, null, 2);
}

export function exportProjectAsMarkdown(project) {
  if (!project) return '';

  const ov = project.overview || {};
  const pr = project.pricing || {};
  const rq = project.requirements || {};
  const ds = project.description || {};
  const gl = project.gallery || {};

  let md = `# Upwork Project Catalog: ${project.name || 'Untitled'}\n\n`;
  md += `> Generated & Validated with Upwork Catalog Studio\n\n`;

  md += `## 1. Overview\n`;
  md += `- **Full Upwork Title**: You will get ${ov.title || '(Not set)'}\n`;
  md += `- **Catalog Title Input**: ${ov.title || '(Not set)'}\n`;
  md += `- **Category**: ${ov.category || '(Not selected)'}\n`;
  md += `- **Search Tags**: ${(ov.searchTags || []).join(', ') || 'None'}\n\n`;

  md += `## 2. Pricing & Value Ladder (${pr.tierMode || 3} Tiers)\n\n`;
  (pr.tiers || []).slice(0, pr.tierMode || 3).forEach((t, i) => {
    md += `### Tier ${i + 1}: ${t.name || 'Tier'}\n`;
    md += `- **Title**: ${t.customTitle || ''}\n`;
    md += `- **Description**: ${t.customDesc || ''}\n`;
    md += `- **Price**: $${t.priceUsd || 0} USD\n`;
    md += `- **Delivery**: ${t.deliveryDays || 1} day(s)\n`;
    md += `- **Revisions**: ${t.revisions || 0}\n`;
    if (t.scopeItems && t.scopeItems.length) {
      md += `- **Deliverables**: ${t.scopeItems.join('; ')}\n`;
    }
    md += `\n`;
  });

  md += `## 3. Gallery (Manual Upload Specs)\n`;
  const images = gl.images || [];
  if (images.length === 0) {
    md += `*No images attached yet. Manually design and upload 4:3 images (e.g. 3600×2700 PNG/JPG) to Upwork.*\n\n`;
  } else {
    images.forEach((img, idx) => {
      md += `- Image #${idx + 1}: \`${img.fileName}\` (${img.width}×${img.height}px, ${(img.sizeBytes / 1024 / 1024).toFixed(2)} MB)\n`;
    });
    md += `\n`;
  }

  md += `## 4. Requirements for Buyers\n`;
  (rq.questions || []).forEach((q, idx) => {
    md += `${idx + 1}. **[${q.isMandatory ? 'Required' : 'Optional'}] (${q.answerType || 'Free text'})**: ${q.question}\n`;
  });
  md += `\n`;

  md += `## 5. Description & Steps\n\n`;
  md += `### Project Summary\n${ds.summary || '(No summary set)'}\n\n`;

  md += `### Project Steps\n`;
  (ds.steps || []).forEach((s, idx) => {
    md += `${idx + 1}. **${s.title}**: ${s.description}\n`;
  });
  md += `\n`;

  if (ds.faqs && ds.faqs.length) {
    md += `### Frequently Asked Questions\n`;
    ds.faqs.forEach((faq, idx) => {
      md += `**Q: ${faq.question}**\n${faq.answer}\n\n`;
    });
  }

  return md;
}

export function importProjectFromJson(rawJson) {
  const check = validateImportJson(rawJson);
  if (!check.valid) {
    throw new Error(check.error);
  }
  saveProject(check.data);
  return check.data;
}

