/**
 * Upwork Catalog Studio — Main Application Controller
 */

import {
  getAllProjects,
  getProject,
  saveProject,
  duplicateProject,
  deleteProject,
  createNewProject,
  getActiveProjectId,
  setActiveProjectId,
  exportProjectAsJson,
  exportProjectAsMarkdown,
  importProjectFromJson
} from './storage.js';

import {
  validateDraft,
  countWords,
  LIMITS
} from './validator.js';

import {
  generateLocalDraft,
  analyzeKeywords
} from './engine.js';

import {
  inspectImageFile,
  inspectVideoFile,
  inspectPdfFile,
  renderPlaceholderCover
} from './gallery-validator.js';

let currentProject = null;
let currentStep = 'overview';
let categories = [];
let autosaveTimeout = null;

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', async () => {
  await loadCategories();
  initProjects();
  initStepNavigation();
  initOverviewListeners();
  initPricingListeners();
  initGalleryListeners();
  initRequirementsListeners();
  initDescriptionListeners();
  initReviewListeners();
  initTopActions();
  initModals();
  renderProjectUI();
});

async function loadCategories() {
  try {
    const res = await fetch('/specs/categories.json');
    if (res.ok) {
      categories = await res.json();
    }
  } catch (err) {
    console.warn('Could not load categories.json, using fallback');
  }

  const catSelect = document.getElementById('projectCategory');
  if (catSelect && categories.length > 0) {
    catSelect.innerHTML = categories.map(c => `<option value="${escapeHtml(c.name)}">${escapeHtml(c.name)}</option>`).join('');
  }
}

function initProjects() {
  const all = getAllProjects();
  const activeId = getActiveProjectId();

  if (activeId && all.some(p => p.id === activeId)) {
    currentProject = getProject(activeId);
  } else if (all.length > 0) {
    currentProject = all[0];
    setActiveProjectId(currentProject.id);
  } else {
    // Create starter project with Brand Identity preset
    currentProject = createNewProject('My First Project Catalog');
    const localContent = generateLocalDraft('brand-identity');
    currentProject.overview = localContent.overview;
    currentProject.pricing = localContent.pricing;
    currentProject.requirements = localContent.requirements;
    currentProject.description = localContent.description;
    saveProject(currentProject);
  }

  renderProjectList();
}

function renderProjectList() {
  const container = document.getElementById('projectList');
  if (!container) return;

  const all = getAllProjects();
  container.innerHTML = all.map(p => `
    <div class="project-item ${p.id === currentProject?.id ? 'active' : ''}" data-id="${p.id}">
      <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(p.name || 'Untitled')}</span>
    </div>
  `).join('');

  container.querySelectorAll('.project-item').forEach(item => {
    item.addEventListener('click', () => {
      const id = item.dataset.id;
      if (id !== currentProject?.id) {
        currentProject = getProject(id);
        setActiveProjectId(id);
        renderProjectList();
        renderProjectUI();
      }
    });
  });
}

function initStepNavigation() {
  const chips = document.querySelectorAll('#stepsNav .step-chip');
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      const step = chip.dataset.step;
      switchStep(step);
    });
  });
}

function switchStep(step) {
  currentStep = step;
  document.querySelectorAll('#stepsNav .step-chip').forEach(c => {
    c.classList.toggle('active', c.dataset.step === step);
  });
  document.querySelectorAll('.step-panel').forEach(p => {
    p.style.display = p.id === `step-${step}` ? 'block' : 'none';
  });
  updateValidationAndQA();
}

function renderProjectUI() {
  if (!currentProject) return;

  // Title & Name
  const nameInput = document.getElementById('projectNameInput');
  if (nameInput) nameInput.value = currentProject.name || '';

  const titleInput = document.getElementById('projectTitle');
  if (titleInput) titleInput.value = currentProject.overview?.title || '';
  updateTitleCounters();

  // Category
  const catSelect = document.getElementById('projectCategory');
  if (catSelect && currentProject.overview?.category) {
    catSelect.value = currentProject.overview.category;
  }
  renderCategoryAttributes();

  // Tags
  renderTagPills();

  // Pricing
  const tierModeSelect = document.getElementById('tierModeSelect');
  if (tierModeSelect) {
    tierModeSelect.value = String(currentProject.pricing?.tierMode || 3);
  }
  renderTierCards();

  // Gallery
  renderGalleryMedia();

  // Requirements
  renderRequirementsList();

  // Description
  const summaryInput = document.getElementById('projectSummary');
  if (summaryInput) summaryInput.value = currentProject.description?.summary || '';
  updateDescCounter();
  renderStepsList();
  renderFaqsList();

  // Review Checkboxes
  const checkCopyright = document.getElementById('checkCopyright');
  if (checkCopyright) checkCopyright.checked = Boolean(currentProject.review?.copyrightDeclaration);
  const checkTerms = document.getElementById('checkTerms');
  if (checkTerms) checkTerms.checked = Boolean(currentProject.review?.termsAgreement);

  updateValidationAndQA();
}

/* ==========================================================================
   Step 1: Overview
   ========================================================================== */

function initOverviewListeners() {
  const titleInput = document.getElementById('projectTitle');
  if (titleInput) {
    titleInput.addEventListener('input', () => {
      if (!currentProject.overview) currentProject.overview = {};
      currentProject.overview.title = titleInput.value;
      updateTitleCounters();
      scheduleAutosave();
    });
  }

  const catSelect = document.getElementById('projectCategory');
  if (catSelect) {
    catSelect.addEventListener('change', () => {
      if (!currentProject.overview) currentProject.overview = {};
      currentProject.overview.category = catSelect.value;
      const matched = categories.find(c => c.name === catSelect.value);
      currentProject.overview.categorySlug = matched ? matched.slug : '';
      renderCategoryAttributes();
      scheduleAutosave();
    });
  }

  const tagInput = document.getElementById('tagInput');
  if (tagInput) {
    tagInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ',') {
        e.preventDefault();
        const val = tagInput.value.trim().replace(/^,+|,+$/g, '');
        if (val) {
          addSearchTag(val);
          tagInput.value = '';
        }
      }
    });
  }
}

function updateTitleCounters() {
  const title = currentProject.overview?.title || '';
  const charCount = title.length;
  const wordCount = countWords(title);
  const counter = document.getElementById('titleCounter');
  const preview = document.getElementById('titlePreview');

  if (counter) {
    counter.textContent = `${charCount} / ${LIMITS.titleMaxChars} chars • ${wordCount} words`;
    counter.className = 'char-counter';
    if (charCount > LIMITS.titleMaxChars || wordCount < LIMITS.titleMinWords) {
      counter.classList.add('over-limit');
    } else if (charCount > 65) {
      counter.classList.add('near-limit');
    }
  }

  if (preview) {
    preview.textContent = title ? `You will get ${title}` : 'You will get ...';
  }

  const sideTitle = document.getElementById('sidePreviewTitle');
  if (sideTitle) {
    sideTitle.textContent = title ? `You will get ${title}` : 'You will get ...';
  }
}

function addSearchTag(tagText) {
  if (!currentProject.overview) currentProject.overview = {};
  if (!Array.isArray(currentProject.overview.searchTags)) currentProject.overview.searchTags = [];

  const clean = tagText.trim().slice(0, LIMITS.tagMaxChars);
  if (!clean) return;

  if (currentProject.overview.searchTags.length >= LIMITS.maxTags) {
    alert(`Upwork allows a maximum of ${LIMITS.maxTags} search tags.`);
    return;
  }

  if (currentProject.overview.searchTags.some(t => t.toLowerCase() === clean.toLowerCase())) {
    return; // Already exists
  }

  currentProject.overview.searchTags.push(clean);
  renderTagPills();
  scheduleAutosave();
}

function removeSearchTag(idx) {
  if (!currentProject.overview?.searchTags) return;
  currentProject.overview.searchTags.splice(idx, 1);
  renderTagPills();
  scheduleAutosave();
}

function renderTagPills() {
  const container = document.getElementById('tagContainer');
  const input = document.getElementById('tagInput');
  const counter = document.getElementById('tagsCounter');
  if (!container || !input) return;

  const tags = currentProject.overview?.searchTags || [];
  if (counter) {
    counter.textContent = `${tags.length} / ${LIMITS.maxTags} tags`;
  }

  // Remove existing pills
  container.querySelectorAll('.tag-pill').forEach(el => el.remove());

  // Insert before input
  tags.forEach((tag, idx) => {
    const pill = document.createElement('div');
    pill.className = 'tag-pill';
    pill.innerHTML = `
      <span>${escapeHtml(tag)}</span>
      <button type="button" data-tag-idx="${idx}">&times;</button>
    `;
    pill.querySelector('button').addEventListener('click', () => removeSearchTag(idx));
    container.insertBefore(pill, input);
  });
}

function renderCategoryAttributes() {
  const container = document.getElementById('attributesList');
  if (!container) return;

  const catName = currentProject.overview?.category;
  const matched = categories.find(c => c.name === catName);

  if (!matched || !matched.attributes || matched.attributes.length === 0) {
    container.innerHTML = '<span style="font-size:12px; color:var(--text-muted);">No specific platform attributes required for this category.</span>';
    return;
  }

  if (!currentProject.overview.attributes) currentProject.overview.attributes = {};

  container.innerHTML = matched.attributes.map(attr => {
    const currentVal = currentProject.overview.attributes[attr.name] || attr.options[0];
    return `
      <div style="display:flex; align-items:center; justify-content:space-between; font-size:13px;">
        <span style="font-weight:500;">${escapeHtml(attr.name)}:</span>
        <select class="select-input attr-select" data-attr="${escapeHtml(attr.name)}" style="width:240px;">
          ${attr.options.map(opt => `<option value="${escapeHtml(opt)}" ${opt === currentVal ? 'selected' : ''}>${escapeHtml(opt)}</option>`).join('')}
        </select>
      </div>
    `;
  }).join('');

  container.querySelectorAll('.attr-select').forEach(sel => {
    sel.addEventListener('change', () => {
      const attrName = sel.dataset.attr;
      currentProject.overview.attributes[attrName] = sel.value;
      scheduleAutosave();
    });
  });
}

/* ==========================================================================
   Step 2: Pricing
   ========================================================================== */

function initPricingListeners() {
  const tierModeSelect = document.getElementById('tierModeSelect');
  if (tierModeSelect) {
    tierModeSelect.addEventListener('change', () => {
      if (!currentProject.pricing) currentProject.pricing = {};
      currentProject.pricing.tierMode = Number(tierModeSelect.value) || 3;
      renderTierCards();
      scheduleAutosave();
    });
  }
}

function renderTierCards() {
  const container = document.getElementById('tiersContainer');
  if (!container) return;

  const tierMode = Number(currentProject.pricing?.tierMode) || 3;
  const tiers = currentProject.pricing?.tiers || [];

  // Default tiers if missing
  while (tiers.length < 3) {
    const idx = tiers.length + 1;
    tiers.push({
      name: idx === 1 ? 'Starter' : idx === 2 ? 'Standard' : 'Advanced',
      customTitle: `Package ${idx}`,
      customDesc: `Comprehensive deliverable level ${idx}`,
      deliveryDays: idx * 2,
      revisions: idx,
      priceUsd: idx * 50,
      scopeItems: []
    });
  }
  if (!currentProject.pricing) currentProject.pricing = {};
  currentProject.pricing.tiers = tiers;

  const activeTiers = tiers.slice(0, tierMode);
  container.style.gridTemplateColumns = tierMode === 1 ? '1fr' : 'repeat(3, 1fr)';

  container.innerHTML = activeTiers.map((t, idx) => `
    <div class="tier-card" data-tier-idx="${idx}">
      <div class="tier-header">
        <span>${escapeHtml(t.name || `Tier ${idx + 1}`)}</span>
        <span style="font-size:12px; color:var(--text-muted);">Tier ${idx + 1}</span>
      </div>

      <div class="form-group">
        <label class="form-label" style="font-size:12px;">Custom Title (Max 30c)</label>
        <input type="text" class="input-text tier-title-input" value="${escapeHtml(t.customTitle || '')}" maxlength="30" placeholder="e.g. Essential Logo">
      </div>

      <div class="form-group">
        <label class="form-label" style="font-size:12px;">Custom Description (Max 80c)</label>
        <input type="text" class="input-text tier-desc-input" value="${escapeHtml(t.customDesc || '')}" maxlength="80" placeholder="e.g. 2 concepts with source files">
      </div>

      <div style="display:flex; gap:10px;">
        <div class="form-group" style="flex:1;">
          <label class="form-label" style="font-size:12px;">Delivery (Days)</label>
          <input type="number" min="1" max="70" class="input-text tier-days-input" value="${t.deliveryDays || 1}">
        </div>
        <div class="form-group" style="flex:1;">
          <label class="form-label" style="font-size:12px;">Revisions</label>
          <input type="text" class="input-text tier-rev-input" value="${t.revisions !== undefined ? t.revisions : 1}">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" style="font-size:12px;">Price (USD)</label>
        <input type="number" min="5" max="500000" class="input-text tier-price-input" value="${t.priceUsd || 50}">
      </div>
    </div>
  `).join('');

  // Attach listeners to tier inputs
  container.querySelectorAll('.tier-card').forEach(card => {
    const idx = Number(card.dataset.tierIdx);
    const titleInput = card.querySelector('.tier-title-input');
    const descInput = card.querySelector('.tier-desc-input');
    const daysInput = card.querySelector('.tier-days-input');
    const revInput = card.querySelector('.tier-rev-input');
    const priceInput = card.querySelector('.tier-price-input');

    titleInput.addEventListener('input', () => {
      tiers[idx].customTitle = titleInput.value;
      scheduleAutosave();
    });
    descInput.addEventListener('input', () => {
      tiers[idx].customDesc = descInput.value;
      scheduleAutosave();
    });
    daysInput.addEventListener('input', () => {
      tiers[idx].deliveryDays = Number(daysInput.value) || 1;
      scheduleAutosave();
    });
    revInput.addEventListener('input', () => {
      tiers[idx].revisions = revInput.value;
      scheduleAutosave();
    });
    priceInput.addEventListener('input', () => {
      tiers[idx].priceUsd = Number(priceInput.value) || 5;
      updateSidePrice();
      scheduleAutosave();
    });
  });

  updateSidePrice();
}

function updateSidePrice() {
  const tiers = currentProject.pricing?.tiers || [];
  const tierMode = Number(currentProject.pricing?.tierMode) || 3;
  const activeTiers = tiers.slice(0, tierMode);
  const minPrice = activeTiers.reduce((min, t) => Math.min(min, Number(t.priceUsd) || 5), Infinity);
  const sidePrice = document.getElementById('sidePreviewPrice');
  if (sidePrice) {
    sidePrice.textContent = `$${minPrice === Infinity ? 50 : minPrice}`;
  }
}

/* ==========================================================================
   Step 3: Gallery (Manual Upload & Stored Image Auto-Upload)
   ========================================================================== */

function initGalleryListeners() {
  const dropzone = document.getElementById('imageDropzone');
  const fileInput = document.getElementById('imageFileInput');
  const videoInput = document.getElementById('videoFileInput');
  const pdfInput = document.getElementById('pdfFileInput');
  const btnPlaceholder = document.getElementById('btnOptionalCoverPlaceholder');

  // Stored Designed Cover Elements
  const coverDropzone = document.getElementById('designedCoverDropzone');
  const coverInput = document.getElementById('designedCoverInput');
  const btnReplaceCover = document.getElementById('btnReplaceDesignedCover');
  const btnRemoveCover = document.getElementById('btnRemoveDesignedCover');

  // Load existing stored image from server on start
  loadStoredCoverMeta();

  if (coverDropzone && coverInput) {
    coverDropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      coverDropzone.classList.add('dragover');
    });
    coverDropzone.addEventListener('dragleave', () => {
      coverDropzone.classList.remove('dragover');
    });
    coverDropzone.addEventListener('drop', async (e) => {
      e.preventDefault();
      coverDropzone.classList.remove('dragover');
      if (e.dataTransfer.files?.length) {
        await handleDesignedCoverUpload(e.dataTransfer.files[0]);
      }
    });
    coverInput.addEventListener('change', async () => {
      if (coverInput.files?.length) {
        await handleDesignedCoverUpload(coverInput.files[0]);
      }
    });
  }

  if (btnReplaceCover && coverInput) {
    btnReplaceCover.addEventListener('click', () => coverInput.click());
  }

  if (btnRemoveCover) {
    btnRemoveCover.addEventListener('click', () => {
      clearStoredCoverUI();
      if (currentProject.gallery?.images?.length) {
        currentProject.gallery.images = currentProject.gallery.images.filter(img => !img.isPrimaryCover);
        renderGalleryMedia();
        scheduleAutosave();
      }
    });
  }

  if (dropzone && fileInput) {
    dropzone.addEventListener('dragover', (e) => {
      e.preventDefault();
      dropzone.classList.add('dragover');
    });

    dropzone.addEventListener('dragleave', () => {
      dropzone.classList.remove('dragover');
    });

    dropzone.addEventListener('drop', async (e) => {
      e.preventDefault();
      dropzone.classList.remove('dragover');
      if (e.dataTransfer.files?.length) {
        await handleImageFiles(e.dataTransfer.files);
      }
    });

    fileInput.addEventListener('change', async () => {
      if (fileInput.files?.length) {
        await handleImageFiles(fileInput.files);
      }
    });
  }

  if (videoInput) {
    videoInput.addEventListener('change', async () => {
      if (videoInput.files?.length) {
        const file = videoInput.files[0];
        const res = await inspectVideoFile(file);
        if (!currentProject.gallery) currentProject.gallery = {};
        currentProject.gallery.videos = [res];
        const statusEl = document.getElementById('videoStatus');
        if (statusEl) {
          statusEl.textContent = `${file.name} (${(file.size / 1024 / 1024).toFixed(1)} MB, ${res.durationSeconds}s) - ${res.valid ? 'Valid' : res.errors.join(', ')}`;
          statusEl.style.color = res.valid ? 'var(--primary)' : 'var(--danger)';
        }
        scheduleAutosave();
      }
    });
  }

  if (pdfInput) {
    pdfInput.addEventListener('change', () => {
      if (pdfInput.files?.length) {
        const list = Array.from(pdfInput.files).slice(0, 2);
        const inspected = list.map(f => inspectPdfFile(f));
        if (!currentProject.gallery) currentProject.gallery = {};
        currentProject.gallery.pdfs = inspected;
        const statusEl = document.getElementById('pdfStatus');
        if (statusEl) {
          statusEl.textContent = `${inspected.length} PDF(s) attached - ${inspected.every(p => p.valid) ? 'Valid' : 'Errors detected'}`;
        }
        scheduleAutosave();
      }
    });
  }

  if (btnPlaceholder) {
    btnPlaceholder.addEventListener('click', () => {
      const canvas = document.getElementById('coverCanvas');
      if (!canvas) return;
      const title = currentProject.overview?.title || 'Professional Service Catalog';
      const category = currentProject.overview?.category || 'Design & Creative';
      renderPlaceholderCover(canvas, { title, category });

      // Create download link for 3600x2700 master PNG
      canvas.toBlob((blob) => {
        if (!blob) return;
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `Upwork_Cover_3600x2700_${Date.now()}.png`;
        a.click();
        URL.revokeObjectURL(url);

        // Add to images list automatically
        if (!currentProject.gallery) currentProject.gallery = {};
        if (!Array.isArray(currentProject.gallery.images)) currentProject.gallery.images = [];
        currentProject.gallery.images.unshift({
          fileName: a.download,
          sizeBytes: blob.size,
          width: 3600,
          height: 2700,
          aspectRatio: '1.33:1',
          status: 'valid'
        });
        renderGalleryMedia();
        scheduleAutosave();
      }, 'image/png');
    });
  }
}

async function loadStoredCoverMeta() {
  try {
    const res = await fetch('/api/active-image-meta');
    if (res.ok) {
      const meta = await res.json();
      if (meta && meta.exists) {
        showStoredCoverUI(meta, '/api/active-image');
      }
    }
  } catch (e) {
    // Local server offline or not loaded yet
  }
}

async function handleDesignedCoverUpload(file) {
  if (!file) return;
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (!['jpg', 'jpeg', 'png'].includes(ext)) {
    return alert('Only JPG or PNG images can be uploaded as project covers.');
  }

  // 1. Inspect image in browser
  const report = await inspectImageFile(file);
  if (!report.valid) {
    alert('Image validation error:\n' + report.errors.join('\n'));
    return;
  }

  // 2. Read as Data URL
  const reader = new FileReader();
  reader.onload = async (e) => {
    const dataUrl = e.target.result;

    // Send to local server
    try {
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: file.name,
          dataUrl,
          width: report.width,
          height: report.height,
          aspectRatio: report.aspectRatio
        })
      });
      const data = await res.json();
      if (data.success && data.meta) {
        showStoredCoverUI(data.meta, dataUrl);
      }
    } catch (err) {
      console.warn('Could not save image to server, keeping in memory/extension:', err);
      showStoredCoverUI({
        fileName: file.name,
        width: report.width,
        height: report.height,
        sizeBytes: file.size,
        aspectRatio: report.aspectRatio
      }, dataUrl);
    }

    // Push to extension storage bridge
    window.postMessage({
      type: 'UPWORK_STUDIO_PUSH_IMAGE',
      imageData: {
        fileName: file.name,
        dataUrl,
        width: report.width,
        height: report.height
      }
    }, '*');

    // Add to project images array as primary cover
    if (!currentProject.gallery) currentProject.gallery = {};
    if (!Array.isArray(currentProject.gallery.images)) currentProject.gallery.images = [];
    currentProject.gallery.images = currentProject.gallery.images.filter(img => !img.isPrimaryCover);
    currentProject.gallery.images.unshift({
      fileName: file.name,
      sizeBytes: file.size,
      width: report.width,
      height: report.height,
      aspectRatio: report.aspectRatio,
      status: 'valid',
      isPrimaryCover: true
    });

    renderGalleryMedia();
    updateValidationAndQA();
    scheduleAutosave();
  };
  reader.readAsDataURL(file);
}

function showStoredCoverUI(meta, srcUrl) {
  const box = document.getElementById('storedImagePreviewBox');
  const dropzone = document.getElementById('designedCoverDropzone');
  const thumb = document.getElementById('storedImageThumb');
  const nameEl = document.getElementById('storedImageName');
  const metaEl = document.getElementById('storedImageMeta');
  const badge = document.getElementById('storedImageBadge');

  if (box && thumb && nameEl && metaEl && badge) {
    thumb.src = srcUrl;
    nameEl.textContent = meta.fileName || 'designed_cover.png';
    const mb = meta.sizeBytes ? (meta.sizeBytes / 1024 / 1024).toFixed(2) + ' MB' : 'Under 10MB';
    metaEl.textContent = `${meta.width || 3600} × ${meta.height || 2700} px • ${mb} • ${meta.aspectRatio || '4:3'}`;
    badge.textContent = '✓ Stored (Auto-Upload Ready)';
    badge.style.background = '#15803d';
    box.style.display = 'block';
    if (dropzone) dropzone.style.display = 'none';
  }
}

function clearStoredCoverUI() {
  const box = document.getElementById('storedImagePreviewBox');
  const dropzone = document.getElementById('designedCoverDropzone');
  const badge = document.getElementById('storedImageBadge');
  if (box) box.style.display = 'none';
  if (dropzone) dropzone.style.display = 'block';
  if (badge) {
    badge.textContent = 'No Image Stored';
    badge.style.background = '#64748b';
  }
}

async function handleImageFiles(files) {
  if (!currentProject.gallery) currentProject.gallery = {};
  if (!Array.isArray(currentProject.gallery.images)) currentProject.gallery.images = [];

  for (const file of files) {
    if (currentProject.gallery.images.length >= LIMITS.maxImages) {
      alert(`Upwork allows a maximum of ${LIMITS.maxImages} images.`);
      break;
    }
    const report = await inspectImageFile(file);
    currentProject.gallery.images.push({
      fileName: file.name,
      sizeBytes: file.size,
      width: report.width,
      height: report.height,
      aspectRatio: report.aspectRatio,
      status: report.valid ? (report.warnings.length ? 'warning' : 'valid') : 'error',
      issues: [...report.errors, ...report.warnings]
    });
  }

  renderGalleryMedia();
  scheduleAutosave();
}

function renderGalleryMedia() {
  const grid = document.getElementById('galleryGrid');
  if (!grid) return;

  const images = currentProject.gallery?.images || [];
  if (images.length === 0) {
    grid.innerHTML = '<div style="grid-column: 1 / -1; font-size:12px; color:var(--text-muted); text-align:center; padding:12px;">No images uploaded yet. Design your 3600×2700 PNG and drop it above.</div>';
    return;
  }

  grid.innerHTML = images.map((img, idx) => {
    const mb = (img.sizeBytes / (1024 * 1024)).toFixed(2);
    const badgeClass = img.status === 'valid' ? 'badge-valid' : img.status === 'warning' ? 'badge-warning' : 'badge-error';
    const badgeText = img.status === 'valid' ? 'Verified' : img.status === 'warning' ? 'Warning' : 'Invalid';

    return `
      <div class="gallery-item">
        <div class="gallery-item-name" title="${escapeHtml(img.fileName)}">${escapeHtml(img.fileName)}</div>
        <div class="gallery-item-specs">
          <div>${img.width} × ${img.height} px</div>
          <div>${mb} MB &bull; ${img.aspectRatio || '4:3'}</div>
        </div>
        <div class="gallery-item-badge ${badgeClass}">${badgeText}</div>
        <button class="btn btn-outline btn-sm remove-img-btn" data-img-idx="${idx}" style="margin-top:4px; font-size:11px; padding:2px 6px;">
          Remove
        </button>
      </div>
    `;
  }).join('');

  grid.querySelectorAll('.remove-img-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.imgIdx);
      currentProject.gallery.images.splice(idx, 1);
      renderGalleryMedia();
      scheduleAutosave();
    });
  });
}

/* ==========================================================================
   Step 4: Requirements
   ========================================================================== */

function initRequirementsListeners() {
  const btnAdd = document.getElementById('btnAddRequirement');
  if (btnAdd) {
    btnAdd.addEventListener('click', () => {
      if (!currentProject.requirements) currentProject.requirements = {};
      if (!Array.isArray(currentProject.requirements.questions)) currentProject.requirements.questions = [];
      if (currentProject.requirements.questions.length >= LIMITS.maxQuestions) {
        alert(`Upwork allows up to ${LIMITS.maxQuestions} requirements.`);
        return;
      }
      currentProject.requirements.questions.push({
        question: 'Please provide all relevant assets, references, and project instructions.',
        answerType: 'Free text',
        isMandatory: true
      });
      renderRequirementsList();
      scheduleAutosave();
    });
  }
}

function renderRequirementsList() {
  const container = document.getElementById('requirementsList');
  if (!container) return;

  const questions = currentProject.requirements?.questions || [];
  if (questions.length === 0) {
    container.innerHTML = '<span style="font-size:12px; color:var(--text-muted);">No requirement questions added yet.</span>';
    return;
  }

  container.innerHTML = questions.map((q, idx) => `
    <div style="border:1px solid var(--border); border-radius:var(--radius-sm); padding:12px; background:#ffffff;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
        <span style="font-weight:600; font-size:12px;">Question #${idx + 1}</span>
        <button class="btn btn-outline btn-sm remove-req-btn" data-req-idx="${idx}" style="color:var(--danger); border-color:var(--border);">Delete</button>
      </div>
      <div class="form-group">
        <textarea class="textarea-input req-text-input" style="min-height:60px;" data-req-idx="${idx}" maxlength="250" placeholder="Type requirement question for the buyer...">${escapeHtml(q.question || '')}</textarea>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:6px; font-size:12px;">
          <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
            <input type="checkbox" class="req-mand-input" data-req-idx="${idx}" ${q.isMandatory ? 'checked' : ''}>
            <span>Mandatory for buyer</span>
          </label>
          <span class="char-counter">${(q.question || '').length} / 250</span>
        </div>
      </div>
    </div>
  `).join('');

  container.querySelectorAll('.req-text-input').forEach(textarea => {
    textarea.addEventListener('input', () => {
      const idx = Number(textarea.dataset.reqIdx);
      questions[idx].question = textarea.value;
      scheduleAutosave();
    });
  });

  container.querySelectorAll('.req-mand-input').forEach(chk => {
    chk.addEventListener('change', () => {
      const idx = Number(chk.dataset.reqIdx);
      questions[idx].isMandatory = chk.checked;
      scheduleAutosave();
    });
  });

  container.querySelectorAll('.remove-req-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.reqIdx);
      questions.splice(idx, 1);
      renderRequirementsList();
      scheduleAutosave();
    });
  });
}

/* ==========================================================================
   Step 5: Description & Steps
   ========================================================================== */

function initDescriptionListeners() {
  const summaryInput = document.getElementById('projectSummary');
  if (summaryInput) {
    summaryInput.addEventListener('input', () => {
      if (!currentProject.description) currentProject.description = {};
      currentProject.description.summary = summaryInput.value;
      updateDescCounter();
      scheduleAutosave();
    });
  }

  const btnAddStep = document.getElementById('btnAddStep');
  if (btnAddStep) {
    btnAddStep.addEventListener('click', () => {
      if (!currentProject.description) currentProject.description = {};
      if (!Array.isArray(currentProject.description.steps)) currentProject.description.steps = [];
      if (currentProject.description.steps.length >= LIMITS.maxSteps) {
        alert(`Upwork allows at most ${LIMITS.maxSteps} project steps.`);
        return;
      }
      currentProject.description.steps.push({
        title: 'New Project Step',
        description: 'Describe what occurs during this milestone.'
      });
      renderStepsList();
      scheduleAutosave();
    });
  }

  const btnAddFaq = document.getElementById('btnAddFaq');
  if (btnAddFaq) {
    btnAddFaq.addEventListener('click', () => {
      if (!currentProject.description) currentProject.description = {};
      if (!Array.isArray(currentProject.description.faqs)) currentProject.description.faqs = [];
      if (currentProject.description.faqs.length >= LIMITS.maxFaqs) {
        alert(`Upwork allows at most ${LIMITS.maxFaqs} FAQs.`);
        return;
      }
      currentProject.description.faqs.push({
        question: 'What is included in this service?',
        answer: 'All specified deliverables are packaged and tested according to the scope.'
      });
      renderFaqsList();
      scheduleAutosave();
    });
  }
}

function updateDescCounter() {
  const summary = currentProject.description?.summary || '';
  const len = summary.length;
  const counter = document.getElementById('descCounter');
  if (counter) {
    counter.textContent = `${len} / ${LIMITS.summaryMaxChars} chars`;
    counter.className = 'char-counter';
    if (len < LIMITS.summaryMinChars || len > LIMITS.summaryMaxChars) {
      counter.classList.add('over-limit');
    } else if (len > 1100) {
      counter.classList.add('near-limit');
    }
  }
}

function renderStepsList() {
  const container = document.getElementById('stepsList');
  if (!container) return;

  const steps = currentProject.description?.steps || [];
  container.innerHTML = steps.map((s, idx) => `
    <div style="border:1px solid var(--border); border-radius:var(--radius-sm); padding:10px; background:#f8fafc;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
        <input type="text" class="input-text step-title-input" data-step-idx="${idx}" maxlength="60" value="${escapeHtml(s.title || '')}" placeholder="Step title (max 60c)" style="flex:1; margin-right:8px; font-weight:600;">
        <button class="btn btn-outline btn-sm remove-step-btn" data-step-idx="${idx}" style="color:var(--danger); border-color:var(--border);">Delete</button>
      </div>
      <input type="text" class="input-text step-desc-input" data-step-idx="${idx}" maxlength="250" value="${escapeHtml(s.description || '')}" placeholder="Step description (max 250c)">
    </div>
  `).join('');

  container.querySelectorAll('.step-title-input').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.stepIdx);
      steps[idx].title = inp.value;
      scheduleAutosave();
    });
  });

  container.querySelectorAll('.step-desc-input').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.stepIdx);
      steps[idx].description = inp.value;
      scheduleAutosave();
    });
  });

  container.querySelectorAll('.remove-step-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.stepIdx);
      steps.splice(idx, 1);
      renderStepsList();
      scheduleAutosave();
    });
  });
}

function renderFaqsList() {
  const container = document.getElementById('faqsList');
  if (!container) return;

  const faqs = currentProject.description?.faqs || [];
  container.innerHTML = faqs.map((f, idx) => `
    <div style="border:1px solid var(--border); border-radius:var(--radius-sm); padding:10px; background:#f8fafc;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
        <input type="text" class="input-text faq-q-input" data-faq-idx="${idx}" maxlength="100" value="${escapeHtml(f.question || '')}" placeholder="Question (max 100c)" style="flex:1; margin-right:8px; font-weight:600;">
        <button class="btn btn-outline btn-sm remove-faq-btn" data-faq-idx="${idx}" style="color:var(--danger); border-color:var(--border);">Delete</button>
      </div>
      <input type="text" class="input-text faq-a-input" data-faq-idx="${idx}" maxlength="250" value="${escapeHtml(f.answer || '')}" placeholder="Answer (max 250c)">
    </div>
  `).join('');

  container.querySelectorAll('.faq-q-input').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.faqIdx);
      faqs[idx].question = inp.value;
      scheduleAutosave();
    });
  });

  container.querySelectorAll('.faq-a-input').forEach(inp => {
    inp.addEventListener('input', () => {
      const idx = Number(inp.dataset.faqIdx);
      faqs[idx].answer = inp.value;
      scheduleAutosave();
    });
  });

  container.querySelectorAll('.remove-faq-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.faqIdx);
      faqs.splice(idx, 1);
      renderFaqsList();
      scheduleAutosave();
    });
  });
}

/* ==========================================================================
   Step 6: Review & Finalize
   ========================================================================== */

function initReviewListeners() {
  const checkCopyright = document.getElementById('checkCopyright');
  const checkTerms = document.getElementById('checkTerms');

  if (checkCopyright) {
    checkCopyright.addEventListener('change', () => {
      if (!currentProject.review) currentProject.review = {};
      currentProject.review.copyrightDeclaration = checkCopyright.checked;
      updateValidationAndQA();
      scheduleAutosave();
    });
  }

  if (checkTerms) {
    checkTerms.addEventListener('change', () => {
      if (!currentProject.review) currentProject.review = {};
      currentProject.review.termsAgreement = checkTerms.checked;
      updateValidationAndQA();
      scheduleAutosave();
    });
  }
}

function updateValidationAndQA() {
  if (!currentProject) return;

  const result = validateDraft(currentProject);
  const badge = document.getElementById('readinessBadge');
  const summaryBox = document.getElementById('validationSummaryBox');

  if (badge) {
    if (result.valid) {
      badge.textContent = '100% Ready for Upwork';
      badge.style.background = 'var(--primary)';
    } else {
      badge.textContent = `${result.errors.length} Issue(s) to Fix`;
      badge.style.background = 'var(--danger)';
    }
  }

  if (summaryBox) {
    if (result.valid) {
      summaryBox.className = 'callout callout-success';
      summaryBox.innerHTML = `<strong>Ready to Publish:</strong> All fields satisfy Upwork Project Catalog constraints! Use the buttons below or the content assistant to upload to Upwork.`;
    } else {
      summaryBox.className = 'callout callout-danger';
      summaryBox.innerHTML = `
        <strong>Please address the following before submitting to Upwork:</strong>
        <ul style="margin:6px 0 0 0; padding-left:18px;">
          ${result.errors.slice(0, 8).map(e => `<li>${escapeHtml(e)}</li>`).join('')}
        </ul>
      `;
    }
  }

  // Update right sidebar section statuses
  updateSectionStatus('overview', result.sections.overview);
  updateSectionStatus('pricing', result.sections.pricing);
  updateSectionStatus('gallery', result.sections.gallery);
  updateSectionStatus('requirements', result.sections.requirements);
  updateSectionStatus('description', result.sections.description);
  updateSectionStatus('review', result.sections.review);
}

function updateSectionStatus(sectionName, sectionResult) {
  const item = document.getElementById(`qa-${sectionName}`);
  const navChip = document.querySelector(`.step-chip[data-step="${sectionName}"]`);
  if (!item) return;

  item.className = 'qa-item';
  if (sectionResult?.valid) {
    item.classList.add('passed');
    if (navChip) navChip.classList.add('valid');
  } else {
    item.classList.add('failed');
    if (navChip) navChip.classList.remove('valid');
  }
}

/* ==========================================================================
   Top Actions & Toolbar
   ========================================================================== */

function initTopActions() {
  const nameInput = document.getElementById('projectNameInput');
  if (nameInput) {
    nameInput.addEventListener('input', () => {
      currentProject.name = nameInput.value;
      renderProjectList();
      scheduleAutosave();
    });
  }

  // Preset Generator (Local / Offline)
  const btnLocal = document.getElementById('btnGenerateLocal');
  const presetSelect = document.getElementById('nichePresetSelect');
  if (btnLocal && presetSelect) {
    btnLocal.addEventListener('click', () => {
      const niche = presetSelect.value;
      const draft = generateLocalDraft(niche);
      currentProject.overview = draft.overview;
      currentProject.pricing = draft.pricing;
      currentProject.requirements = draft.requirements;
      currentProject.description = draft.description;
      saveProject(currentProject);
      renderProjectUI();
      alert(`Local draft for "${presetSelect.selectedOptions[0].text}" loaded! All copy generated 100% locally.`);
    });
  }

  // Gemini AI Generator
  const btnGemini = document.getElementById('btnGenerateGemini');
  if (btnGemini) {
    btnGemini.addEventListener('click', async () => {
      const origText = btnGemini.textContent;
      btnGemini.textContent = 'Generating...';
      btnGemini.disabled = true;

      try {
        const nicheText = presetSelect ? presetSelect.selectedOptions[0].text : 'Brand Identity';
        const res = await fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            niche: nicheText,
            brief: currentProject.name || '',
            customKeywords: (currentProject.overview?.searchTags || []).join(', ')
          })
        });

        if (res.status === 503) {
          const data = await res.json();
          alert(`${data.error}\n\n${data.message}`);
          return;
        }

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || `Server responded with ${res.status}`);
        }

        const data = await res.json();
        if (data.data) {
          if (data.data.overview) currentProject.overview = { ...currentProject.overview, ...data.data.overview };
          if (data.data.pricing) currentProject.pricing = data.data.pricing;
          if (data.data.requirements) currentProject.requirements = data.data.requirements;
          if (data.data.description) currentProject.description = data.data.description;
          saveProject(currentProject);
          renderProjectUI();
          alert('Gemini AI successfully generated your complete project catalog draft!');
        }
      } catch (err) {
        alert('Gemini generation failed: ' + err.message + '\n\nNote: You can use the "Generate Local Draft" button right next to it, which works offline with zero API key!');
      } finally {
        btnGemini.textContent = origText;
        btnGemini.disabled = false;
      }
    });
  }

  // Push directly to Chrome Extension & Local Studio Server
  const btnPush = document.getElementById('btnPushToExtension');
  if (btnPush) {
    btnPush.addEventListener('click', async () => {
      const origText = btnPush.innerHTML;
      btnPush.innerHTML = 'Pushing...';

      // 1. Post to window for extension content script bridge
      window.postMessage({
        type: 'UPWORK_STUDIO_PUSH_PROJECT',
        project: currentProject
      }, '*');

      // 2. Post to server endpoint for persistent sync
      let serverSaved = false;
      try {
        const res = await fetch('/api/project', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ project: currentProject })
        });
        serverSaved = res.ok;
      } catch (e) {
        console.warn('Could not post project to server:', e);
      }

      btnPush.innerHTML = '✓ Pushed to Extension!';
      btnPush.style.background = '#15803d';

      setTimeout(() => {
        btnPush.innerHTML = origText;
        btnPush.style.background = '';
      }, 2500);
    });
  }

  // Listen for extension connection responses
  window.addEventListener('message', (event) => {
    if (event.data?.type === 'UPWORK_STUDIO_PUSH_SUCCESS') {
      const btn = document.getElementById('btnPushToExtension');
      if (btn) {
        btn.innerHTML = '✓ Extension Synced!';
        btn.style.background = '#15803d';
      }
    }
  });

  // New, Duplicate, Delete
  const btnNew = document.getElementById('btnNewProject');
  if (btnNew) {
    btnNew.addEventListener('click', () => {
      currentProject = createNewProject('New Project Catalog');
      renderProjectList();
      renderProjectUI();
    });
  }

  const btnDup = document.getElementById('btnDuplicateProject');
  if (btnDup) {
    btnDup.addEventListener('click', () => {
      const dup = duplicateProject(currentProject.id);
      if (dup) {
        currentProject = dup;
        renderProjectList();
        renderProjectUI();
      }
    });
  }

  const btnDel = document.getElementById('btnDeleteProject');
  if (btnDel) {
    btnDel.addEventListener('click', () => {
      if (confirm(`Are you sure you want to delete "${currentProject.name}"?`)) {
        deleteProject(currentProject.id);
        initProjects();
        renderProjectUI();
      }
    });
  }

  // Export & Import
  const btnExpJson = document.getElementById('btnExportJson');
  if (btnExpJson) {
    btnExpJson.addEventListener('click', () => {
      const json = exportProjectAsJson(currentProject);
      downloadFile(json, `${sanitizeFilename(currentProject.name)}.json`, 'application/json');
    });
  }

  const btnExpMd = document.getElementById('btnExportMarkdown');
  if (btnExpMd) {
    btnExpMd.addEventListener('click', () => {
      const md = exportProjectAsMarkdown(currentProject);
      downloadFile(md, `${sanitizeFilename(currentProject.name)}.md`, 'text/markdown');
    });
  }

  const importInput = document.getElementById('importFileInput');
  if (importInput) {
    importInput.addEventListener('change', () => {
      if (!importInput.files?.length) return;
      const file = importInput.files[0];
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const imported = importProjectFromJson(e.target.result);
          currentProject = imported;
          renderProjectList();
          renderProjectUI();
          alert(`Project "${imported.name}" successfully imported!`);
        } catch (err) {
          alert('Import failed: ' + err.message);
        }
      };
      reader.readAsText(file);
    });
  }

  // Quick Copy Sidebar Buttons
  initQuickCopyButtons();
}

function initQuickCopyButtons() {
  setupCopyBtn('btnCopyTitle', () => currentProject.overview?.title || '');
  setupCopyBtn('btnCopyTags', () => (currentProject.overview?.searchTags || []).join(', '));
  setupCopyBtn('btnCopyPricing', () => {
    const pr = currentProject.pricing || {};
    return (pr.tiers || []).map(t => `${t.name}: $${t.priceUsd} - ${t.customTitle} (${t.deliveryDays}d delivery)`).join('\n');
  });
  setupCopyBtn('btnCopySummary', () => currentProject.description?.summary || '');
}

function setupCopyBtn(btnId, getTextFn) {
  const btn = document.getElementById(btnId);
  if (!btn) return;
  btn.addEventListener('click', () => {
    const text = getTextFn();
    navigator.clipboard.writeText(text).then(() => {
      const orig = btn.textContent;
      btn.textContent = 'Copied!';
      setTimeout(() => btn.textContent = orig, 1200);
    });
  });
}

/* ==========================================================================
   Modals: Keyword Research & Copy Drawer
   ========================================================================== */

function initModals() {
  // Keyword Modal
  const kwModal = document.getElementById('keywordModal');
  const btnOpenKw = document.getElementById('btnOpenKeywords');
  const btnCloseKw = document.getElementById('btnCloseKeywordModal');
  const btnAnalyzeKw = document.getElementById('btnAnalyzeKeywords');
  const kwInput = document.getElementById('kwInput');
  const kwResults = document.getElementById('kwResults');
  const kwTagPills = document.getElementById('kwTagPills');
  const btnApplyKw = document.getElementById('btnApplyKwTags');

  let analyzedTopTags = [];

  if (btnOpenKw && kwModal) {
    btnOpenKw.addEventListener('click', () => kwModal.style.display = 'flex');
  }
  if (btnCloseKw && kwModal) {
    btnCloseKw.addEventListener('click', () => kwModal.style.display = 'none');
  }

  if (btnAnalyzeKw && kwInput && kwResults && kwTagPills) {
    btnAnalyzeKw.addEventListener('click', () => {
      const report = analyzeKeywords(kwInput.value);
      analyzedTopTags = report.recommendedTags;
      kwTagPills.innerHTML = analyzedTopTags.map(t => `
        <span class="tag-pill" style="background:#eef7ee; border-color:#108a00; color:#065f46; font-weight:600;">${escapeHtml(t)}</span>
      `).join('');
      kwResults.style.display = 'block';
    });
  }

  if (btnApplyKw && kwModal) {
    btnApplyKw.addEventListener('click', () => {
      if (analyzedTopTags.length > 0) {
        if (!currentProject.overview) currentProject.overview = {};
        currentProject.overview.searchTags = [...analyzedTopTags.slice(0, 5)];
        renderTagPills();
        scheduleAutosave();
        kwModal.style.display = 'none';
        alert('Top 5 tags applied to your Project Overview!');
      }
    });
  }

  // Copy Drawer Modal
  const drawerModal = document.getElementById('copyDrawerModal');
  const btnOpenDrawer = document.getElementById('btnOpenCopyDrawer');
  const btnCloseDrawer = document.getElementById('btnCloseCopyDrawer');
  const drawerContent = document.getElementById('drawerCopyContent');

  if (btnOpenDrawer && drawerModal && drawerContent) {
    btnOpenDrawer.addEventListener('click', () => {
      renderDrawerFields(drawerContent);
      drawerModal.style.display = 'flex';
    });
  }
  if (btnCloseDrawer && drawerModal) {
    btnCloseDrawer.addEventListener('click', () => drawerModal.style.display = 'none');
  }
}

function renderDrawerFields(container) {
  const ov = currentProject.overview || {};
  const pr = currentProject.pricing || {};
  const rq = currentProject.requirements || {};
  const ds = currentProject.description || {};

  const fields = [
    { label: 'Project Title (Upwork Input)', value: ov.title || '' },
    { label: 'Search Tags', value: (ov.searchTags || []).join(', ') },
    { label: 'Project Summary / Description', value: ds.summary || '' },
    { label: 'Buyer Requirements', value: (rq.questions || []).map((q, i) => `${i + 1}. ${q.question}`).join('\n\n') },
    { label: 'Frequently Asked Questions', value: (ds.faqs || []).map(f => `Q: ${f.question}\nA: ${f.answer}`).join('\n\n') }
  ];

  container.innerHTML = fields.map((f, i) => `
    <div style="border:1px solid var(--border); border-radius:var(--radius-sm); padding:12px; background:#f8fafc;">
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
        <span style="font-weight:600; font-size:13px;">${escapeHtml(f.label)}</span>
        <button class="btn btn-outline btn-sm drawer-copy-btn" data-drawer-idx="${i}">Copy Text</button>
      </div>
      <div style="font-size:12px; color:var(--text-muted); max-height:80px; overflow-y:auto; white-space:pre-wrap; background:#fff; padding:6px; border-radius:4px; border:1px solid #e2e8f0;">${escapeHtml(f.value || '(Empty)')}</div>
    </div>
  `).join('');

  container.querySelectorAll('.drawer-copy-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const idx = Number(btn.dataset.drawerIdx);
      const val = fields[idx].value;
      navigator.clipboard.writeText(val).then(() => {
        const orig = btn.textContent;
        btn.textContent = 'Copied!';
        setTimeout(() => btn.textContent = orig, 1200);
      });
    });
  });
}

function scheduleAutosave() {
  clearTimeout(autosaveTimeout);
  autosaveTimeout = setTimeout(() => {
    if (currentProject) {
      saveProject(currentProject);
      updateValidationAndQA();
    }
  }, 400);
}

function downloadFile(content, fileName, mimeType) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();
  URL.revokeObjectURL(url);
}

function sanitizeFilename(name) {
  return (name || 'project').replace(/[^a-z0-9_-]/gi, '_').toLowerCase();
}

function escapeHtml(str) {
  return String(str || '').replace(/[&<>"']/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[s]));
}

