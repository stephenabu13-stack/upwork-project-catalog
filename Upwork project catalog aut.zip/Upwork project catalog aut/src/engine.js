/**
 * Content Research and Local Drafting Engine for Upwork Project Catalog
 * Generates tailored, policy-compliant copy and keyword intelligence across core freelance niches.
 */

export const NICHES = {
  'brand-identity': {
    name: 'Brand Identity & Logo Design',
    categoryName: 'Design & Creative > Brand Identity Design',
    categorySlug: 'brand-identity',
    titleTemplates: [
      'a modern brand identity design with custom vector logo and style guide',
      'a memorable minimalist logo design with full corporate brand guidelines',
      'a premium business logo design with vector assets and social media kit'
    ],
    recommendedTags: ['brand identity', 'logo design', 'minimalist logo', 'style guide', 'vector logo'],
    attributes: { Style: 'Minimalist', 'File Formats': 'AI, SVG, PDF, PNG' },
    tiers: [
      {
        name: 'Starter',
        customTitle: 'Essential Logo Mark',
        customDesc: '2 primary logo concepts, high-resolution PNG and vector SVG source files',
        deliveryDays: 3,
        revisions: 2,
        priceUsd: 75,
        scopeItems: ['2 Logo Concepts', 'Vector SVG', 'Transparent PNG', 'Commercial License']
      },
      {
        name: 'Standard',
        customTitle: 'Complete Brand Identity',
        customDesc: '3 concepts, primary & secondary logos, typography system, color palette',
        deliveryDays: 5,
        revisions: 4,
        priceUsd: 185,
        scopeItems: ['3 Logo Concepts', 'Secondary Submark', 'Brand Color Palette', 'Typography Pairing', 'Source Files (AI, EPS)']
      },
      {
        name: 'Advanced',
        customTitle: 'Full Corporate Brand Suite',
        customDesc: 'Comprehensive brand style guide PDF, social media banners, and full vector kit',
        deliveryDays: 7,
        revisions: 'unlimited',
        priceUsd: 380,
        scopeItems: ['Full Brand Style Guide', 'Social Media Kit', 'Stationery Mockups', 'Favicon & App Icon', 'All Source Assets']
      }
    ],
    requirements: [
      { question: 'What is your company or brand name, and what product or service do you offer?', answerType: 'Free text', isMandatory: true },
      { question: 'Who is your ideal target customer, and what 3 words best describe your desired brand personality?', answerType: 'Free text', isMandatory: true },
      { question: 'Do you have existing color preferences, brand assets, or competitor logos you like or dislike?', answerType: 'Free text', isMandatory: false }
    ],
    summary: 'Elevate your business with a distinctive, enduring brand identity crafted for modern digital and print touchpoints. Rather than generic clip-art, you will receive original vector designs built from strategic research into your industry, audience, and competitors. Every deliverable is provided in production-ready formats so your brand looks crisp across web, mobile, apparel, and signage.',
    steps: [
      { title: 'Brand Discovery & Moodboarding', description: 'Review your brief, analyze competitors, and align on visual direction.' },
      { title: 'Concept Creation & Vectorizing', description: 'Design initial logo marks and explore balanced typography and palettes.' },
      { title: 'Review & Iterative Polish', description: 'Refine chosen concepts based on your targeted feedback.' },
      { title: 'Final Asset Export & Style Guide', description: 'Package all print/web vectors, fonts, color codes, and usage guidelines.' }
    ],
    faqs: [
      { question: 'What files will I receive for my logo and brand?', answer: 'You will receive industry-standard vector files (AI, EPS, SVG) alongside high-resolution transparent PNG and print-ready PDF files.' },
      { question: 'Do I own full commercial rights to the designs?', answer: 'Yes, upon project completion and release of payment, you hold 100% full commercial copyright to the finalized assets.' },
      { question: 'Can I request color or font adjustments during the project?', answer: 'Absolutely. We review concepts collaboratively and make necessary adjustments within your package revisions.' },
      { question: 'How do I upload the images to Upwork?', answer: 'You can export your draft here, design your custom 3600×2700 PNG covers, and upload them directly in Upwork Catalog.' }
    ]
  },

  'wordpress-woo': {
    name: 'WordPress & WooCommerce Development',
    categoryName: 'Web, Mobile & Software Dev > WordPress & WooCommerce',
    categorySlug: 'wordpress-woo',
    titleTemplates: [
      'a high-converting WooCommerce store optimized for mobile speed and sales',
      'a custom responsive WordPress website with modern design and fast load times',
      'a professional WooCommerce online shop with payment gateway setup and security'
    ],
    recommendedTags: ['wordpress website', 'woocommerce store', 'speed optimization', 'elementor expert', 'ecommerce website'],
    attributes: { 'Page Builder': 'Elementor', 'Store Type': 'Physical Products' },
    tiers: [
      {
        name: 'Starter',
        customTitle: 'Speed & Bug Fix Package',
        customDesc: 'Core Web Vitals audit, cache setup, image optimization, and 3 key fixes',
        deliveryDays: 2,
        revisions: 2,
        priceUsd: 95,
        scopeItems: ['Cache Optimization', 'Image Compression', 'Database Cleanup', 'Speed Benchmark Report']
      },
      {
        name: 'Standard',
        customTitle: 'Business Website Build',
        customDesc: 'Up to 5 responsive pages, contact forms, SEO setup, and security hardening',
        deliveryDays: 6,
        revisions: 3,
        priceUsd: 295,
        scopeItems: ['5 Custom Pages', 'Mobile Responsive Layout', 'Contact & Lead Forms', 'On-page SEO Basics', 'SSL & Security Setup']
      },
      {
        name: 'Advanced',
        customTitle: 'Full WooCommerce E-commerce',
        customDesc: 'Full store build with Stripe/PayPal setup, products catalog, and shipping rules',
        deliveryDays: 10,
        revisions: 5,
        priceUsd: 550,
        scopeItems: ['Full WooCommerce Setup', 'Payment & Shipping Rules', 'Up to 15 Products Uploaded', 'Speed & Security Hardening', 'Admin Video Walkthrough']
      }
    ],
    requirements: [
      { question: 'What is your domain name, and do you already have WordPress hosting set up?', answerType: 'Free text', isMandatory: true },
      { question: 'Please list your main pages (e.g. Home, About, Shop, Contact) and provide your branding/content materials.', answerType: 'Free text', isMandatory: true },
      { question: 'Which payment gateways (Stripe, PayPal) and shipping methods will your store require?', answerType: 'Free text', isMandatory: false }
    ],
    summary: 'Build a blazing-fast, mobile-responsive WordPress and WooCommerce storefront engineered to convert visitors into loyal customers. Each website is built using clean architecture, avoiding bloated plugins that slow down loading times. Includes comprehensive on-page SEO foundations, SSL security configuration, payment gateway integration, and intuitive backend controls so you can manage products effortlessly.',
    steps: [
      { title: 'Architecture & Theme Setup', description: 'Configure staging environment, clean theme framework, and SSL/security.' },
      { title: 'Page Design & Content Integration', description: 'Build responsive pages, product layouts, and checkout experience.' },
      { title: 'Payment & Shipping Configuration', description: 'Connect Stripe, PayPal, tax calculations, and automated transactional emails.' },
      { title: 'Speed Audit & Launch QA', description: 'Optimize Core Web Vitals, test cross-browser compatibility, and handover.' }
    ],
    faqs: [
      { question: 'Will I be able to edit text and products without coding?', answer: 'Yes, your site is set up with an intuitive visual editor and WooCommerce dashboard, allowing you to edit text and products easily.' },
      { question: 'Is the website optimized for mobile phones and tablets?', answer: 'Every page is custom-tested on mobile, tablet, and desktop viewports to ensure seamless user experience and fast loading.' },
      { question: 'Do you help migrate or point my domain when ready?', answer: 'Yes, I guide you through pointing your domain or migrating from staging to your live hosting server.' }
    ]
  },

  'seo-optimization': {
    name: 'Search Engine Optimization (SEO)',
    categoryName: 'Sales & Marketing > Search Engine Optimization (SEO)',
    categorySlug: 'seo-optimization',
    titleTemplates: [
      'a comprehensive technical SEO audit and actionable on-page ranking roadmap',
      'an in-depth on-page SEO optimization package for organic search traffic',
      'a high-impact keyword research and competitive SEO content strategy'
    ],
    recommendedTags: ['technical seo', 'on page seo', 'keyword research', 'seo audit', 'search console'],
    attributes: { 'Focus Area': 'Technical SEO', 'CMS Familiarity': 'WordPress' },
    tiers: [
      {
        name: 'Starter',
        customTitle: 'Technical Crawl & Audit',
        customDesc: 'Site health crawl, broken links audit, index review, and priority action report',
        deliveryDays: 3,
        revisions: 1,
        priceUsd: 80,
        scopeItems: ['Crawl Error Analysis', 'Indexation Check', 'Sitemap & Robots.txt Review', 'Priority Issue Checklist']
      },
      {
        name: 'Standard',
        customTitle: 'On-Page Core Optimization',
        customDesc: 'Audit + title tags, meta descriptions, and H1-H3 structure for 8 priority pages',
        deliveryDays: 5,
        revisions: 2,
        priceUsd: 195,
        scopeItems: ['8 Priority Pages Optimized', 'Keyword Intent Mapping', 'Meta Titles & Descriptions', 'Internal Linking Architecture']
      },
      {
        name: 'Advanced',
        customTitle: 'Full Growth Strategy & Schema',
        customDesc: 'Full technical fixes, structured schema markup, and 90-day SEO content plan',
        deliveryDays: 8,
        revisions: 3,
        priceUsd: 380,
        scopeItems: ['Complete Technical Remediation', 'JSON-LD Schema Markup', '15 Pages Optimized', 'Competitor Gap Analysis', '90-Day Content Roadmap']
      }
    ],
    requirements: [
      { question: 'What is your website URL, and which primary countries/markets are you targeting?', answerType: 'Free text', isMandatory: true },
      { question: 'Who are your top 2-3 direct business competitors?', answerType: 'Free text', isMandatory: true },
      { question: 'Do you have Google Search Console and Google Analytics installed on your site?', answerType: 'Free text', isMandatory: false }
    ],
    summary: 'Drive sustainable organic traffic to your website with systematic, data-backed Search Engine Optimization. Rather than guessing, this project identifies critical crawl bottlenecks, indexes orphaned assets, aligns page content with commercial buyer intent, and implements clean schema markup. You receive an actionable, transparent roadmap to improve visibility without risky black-hat shortcuts.',
    steps: [
      { title: 'Technical Crawl & Health Check', description: 'Analyze site architecture, response codes, page speed, and index coverage.' },
      { title: 'Keyword Intent & Gap Analysis', description: 'Identify high-intent search terms your competitors rank for.' },
      { title: 'On-Page Optimization & Schema', description: 'Optimize page metadata, heading tags, internal links, and JSON-LD markup.' },
      { title: 'Reporting & Strategy Roadmap', description: 'Deliver clean documentation detailing all fixes and next-step recommendations.' }
    ],
    faqs: [
      { question: 'How quickly will my website rank on Google?', answer: 'SEO is a compounding process; on-page fixes are indexed within 2-6 weeks, with meaningful ranking improvements typically compounding over 2-3 months.' },
      { question: 'Do you use white-hat, Google-compliant techniques?', answer: 'Yes, 100% safe, white-hat practices strictly aligned with Google Search Essentials and Webmaster Guidelines.' },
      { question: 'Will you need access to my website admin panel?', answer: 'For direct implementation, yes. Alternatively, I can provide a step-by-step implementation guide for your development team.' }
    ]
  },

  'social-ads': {
    name: 'Social Media Ad Creatives & Graphics',
    categoryName: 'Design & Creative > Social Media Design & Ad Creatives',
    categorySlug: 'social-ads',
    titleTemplates: [
      'high-converting social media ad creatives for Facebook Instagram and TikTok',
      'scroll-stopping paid social ad graphics with high-CTR headline hooks',
      'engaging carousel ad designs and promotional graphics for paid campaigns'
    ],
    recommendedTags: ['ad creatives', 'facebook ads', 'instagram design', 'social media graphics', 'canva figma'],
    attributes: { Platform: 'Meta (Facebook/Instagram)', 'Deliverable Type': 'Static Creatives' },
    tiers: [
      {
        name: 'Starter',
        customTitle: '3 High-CTR Ad Creatives',
        customDesc: '3 distinct static ad graphics formatted for Meta feed (1:1) and stories (9:16)',
        deliveryDays: 2,
        revisions: 2,
        priceUsd: 60,
        scopeItems: ['3 Ad Designs', 'Feed & Story Sizes', 'Headline Hook Copy', 'High-Res PNG/JPG']
      },
      {
        name: 'Standard',
        customTitle: '6 Creative Testing Bundle',
        customDesc: '6 scroll-stopping ad concepts testing multiple hooks, angles, and visual styles',
        deliveryDays: 4,
        revisions: 3,
        priceUsd: 140,
        scopeItems: ['6 Unique Concepts', 'Hook Variation Testing', 'Figma/Canva Source Assets', 'Commercial Rights']
      },
      {
        name: 'Advanced',
        customTitle: 'Full Campaign Creative Kit',
        customDesc: '12 multi-format ad assets with carousels, retargeting banners, and source files',
        deliveryDays: 6,
        revisions: 4,
        priceUsd: 260,
        scopeItems: ['12 Multi-Platform Assets', '2 Carousel Ad Sets', 'Retargeting Graphics', 'Editable Source Files', 'Ad Copy Angle Guide']
      }
    ],
    requirements: [
      { question: 'What product, offer, or service are these ads promoting, and what is your landing page URL?', answerType: 'Free text', isMandatory: true },
      { question: 'Which advertising platforms are you targeting (Meta, TikTok, LinkedIn)?', answerType: 'Free text', isMandatory: true },
      { question: 'Please share your brand logo, color guidelines, and any product photography or creative assets you have.', answerType: 'Free text', isMandatory: false }
    ],
    summary: 'Stop the scroll and drive measurable clicks with professionally crafted social media ad creatives designed specifically for paid performance marketing. We combine conversion-focused layout psychology, clear visual hierarchy, bold typographic hooks, and compliant branding that gets approved fast by ad review algorithms. Designed for direct response on Meta, TikTok, and LinkedIn.',
    steps: [
      { title: 'Audience & Offer Breakdown', description: 'Analyze your product offer, customer pain points, and top competitor creatives.' },
      { title: 'Hook Drafting & Concepting', description: 'Formulate high-contrast visual angles, headline treatments, and call-to-actions.' },
      { title: 'Design & Multi-Size Formatting', description: 'Build pixel-perfect graphics in 1:1, 9:16, and 4:5 aspect ratios.' },
      { title: 'Final Handover & Source Assets', description: 'Export crisp JPG/PNG files ready for immediate upload to Ads Manager.' }
    ],
    faqs: [
      { question: 'What image sizes and dimensions will I receive?', answer: 'You receive 1:1 Square (1080×1080) for feeds and 9:16 Vertical (1080×1920) for Stories and Reels, formatted for Meta and TikTok.' },
      { question: 'Can you write the headline copy on the graphics?', answer: 'Yes, each ad includes conversion-optimized headline hooks and sub-copy tailored to your offer.' },
      { question: 'Do you provide editable source files?', answer: 'Yes, Standard and Advanced tiers include editable Figma or Canva source links.' }
    ]
  },

  'book-reading': {
    name: 'Book Formatting & Beta Reading',
    categoryName: 'Writing & Translation > Book Formatting & Beta Reading',
    categorySlug: 'book-reading',
    titleTemplates: [
      'professional interior book formatting for Amazon KDP paperback and EPUB',
      'flawless book layout and interior formatting for print and Kindle eBook',
      'an insightful manuscript beta reading critique and comprehensive pacing report'
    ],
    recommendedTags: ['book formatting', 'kdp formatting', 'epub conversion', 'paperback layout', 'beta reading'],
    attributes: { 'Genre Focus': 'Fiction / Fantasy / Sci-Fi', 'Trim Sizes': '5.5 x 8.5 in' },
    tiers: [
      {
        name: 'Starter',
        customTitle: 'eBook Kindle EPUB Layout',
        customDesc: 'Clean reflowable EPUB for Kindle & Apple Books, up to 25k words with TOC',
        deliveryDays: 3,
        revisions: 2,
        priceUsd: 65,
        scopeItems: ['Up to 25k Words', 'Reflowable EPUB', 'Clickable TOC', 'Device Tested']
      },
      {
        name: 'Standard',
        customTitle: 'Print & eBook KDP Duo',
        customDesc: 'Print-ready PDF with mirrored margins + reflowable EPUB up to 60k words',
        deliveryDays: 5,
        revisions: 3,
        priceUsd: 145,
        scopeItems: ['Up to 60k Words', 'Print PDF with Headers', 'Reflowable EPUB', 'Drop Caps & Ornamentation', 'KDP Upload Guarantee']
      },
      {
        name: 'Advanced',
        customTitle: 'Deluxe Format + Beta Review',
        customDesc: 'Dual formatting up to 90k words + detailed 4-page reader critique report',
        deliveryDays: 8,
        revisions: 4,
        priceUsd: 275,
        scopeItems: ['Up to 90k Words', 'Print PDF & EPUB', '4-Page Reader Report', 'Pacing & Character Analysis', 'Custom Chapter Title Graphics']
      }
    ],
    requirements: [
      { question: 'What is your book title, genre, and word count?', answerType: 'Free text', isMandatory: true },
      { question: 'What trim size do you prefer for your paperback (e.g., 5.5×8.5 in, 6×9 in)?', answerType: 'Free text', isMandatory: true },
      { question: 'Please share your final proofread manuscript file (.docx or .odt).', answerType: 'Free text', isMandatory: true }
    ],
    summary: 'Transform your manuscript into an elegant, publication-ready book that meets every technical specification for Amazon KDP, IngramSpark, and Apple Books. Your print edition will feature professional typography, balanced running headers, mirrored gutters, and custom chapter breaks, while your eBook edition delivers a flawless reflowable reading experience with a clickable table of contents.',
    steps: [
      { title: 'Manuscript Review & Cleanup', description: 'Inspect Word styles, line breaks, footnotes, and front/back matter structure.' },
      { title: 'Interior Layout Styling', description: 'Configure trim margins, chapter heading typography, and page number folios.' },
      { title: 'EPUB & PDF Compilation', description: 'Generate high-resolution print PDF and validated reflowable EPUB files.' },
      { title: 'Validation & Upload Check', description: 'Test files against Kindle Previewer and KDP print verification standards.' }
    ],
    faqs: [
      { question: 'Will my book pass Amazon KDP review without errors?', answer: 'Yes, every formatted file is tested against KDP automated verification and guaranteed to pass interior checks.' },
      { question: 'Can you include custom chapter header images or ornaments?', answer: 'Yes, custom decorative headers and flourishes are included in Standard and Advanced tiers.' },
      { question: 'What trim sizes can you prepare for paperback?', answer: 'All standard industry sizes, including 5×8, 5.25×8, 5.5×8.5, and 6×9 inches.' }
    ]
  }
};

/**
 * Generates high quality project draft contents based on niche or custom brief
 */
export function generateLocalDraft(nicheKey = 'brand-identity', customBrief = '') {
  const template = NICHES[nicheKey] || NICHES['brand-identity'];

  const customKeywords = customBrief
    ? customBrief.split(/[,;\n]+/).map(s => s.trim().toLowerCase()).filter(s => s.length > 2)
    : [];

  let title = template.titleTemplates[0];
  let tags = [...template.recommendedTags];

  if (customKeywords.length > 0) {
    tags = Array.from(new Set([...customKeywords.slice(0, 3), ...tags])).slice(0, 5);
  }

  // Ensure title meets word count >= 7 and chars <= 75 and does not start with "You will get"
  if (title.length > 75) {
    title = title.slice(0, 75).trim();
  }

  return {
    overview: {
      title,
      category: template.categoryName,
      categorySlug: template.categorySlug,
      searchTags: tags,
      attributes: { ...template.attributes }
    },
    pricing: {
      tierMode: 3,
      tiers: JSON.parse(JSON.stringify(template.tiers))
    },
    gallery: {
      // Manual image upload guidance: User handles custom images
      images: [],
      videos: [],
      pdfs: []
    },
    requirements: {
      questions: JSON.parse(JSON.stringify(template.requirements))
    },
    description: {
      summary: template.summary,
      steps: JSON.parse(JSON.stringify(template.steps)),
      faqs: JSON.parse(JSON.stringify(template.faqs))
    },
    review: {
      copyrightDeclaration: false,
      termsAgreement: false
    }
  };
}

/**
 * Keyword Research Helper
 * Analyzes input keywords, calculates intent score, and suggests title/tag optimization
 */
export function analyzeKeywords(keywordInput = '') {
  if (!keywordInput || typeof keywordInput !== 'string') {
    return { keywords: [], recommendedTags: [], titleSuggestions: [] };
  }

  const rawList = keywordInput
    .split(/[\n,;]+/)
    .map(k => k.trim())
    .filter(k => k.length > 1);

  const analyzed = rawList.map(kw => {
    const lower = kw.toLowerCase();
    let intent = 'Informational';
    let weight = 50;

    // Commercial & Transactional intent triggers
    if (/(hire|buy|service|expert|designer|developer|agency|specialist|freelancer)/.test(lower)) {
      intent = 'High Buyer Intent';
      weight += 35;
    } else if (/(cost|price|quote|package|custom|professional|audit)/.test(lower)) {
      intent = 'Commercial Investigation';
      weight += 25;
    }

    if (kw.length <= 30) {
      weight += 10;
    }

    return {
      keyword: kw,
      intent,
      fitForTag: kw.length <= 30,
      score: weight
    };
  });

  analyzed.sort((a, b) => b.score - a.score);

  const topTags = analyzed
    .filter(a => a.fitForTag)
    .slice(0, 5)
    .map(a => a.keyword.toLowerCase());

  return {
    keywords: analyzed,
    recommendedTags: topTags
  };
}
