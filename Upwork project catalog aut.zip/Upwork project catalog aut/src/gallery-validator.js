/**
 * Media & Gallery Inspector for Manual Image Uploads
 * Verifies user-designed files against Upwork Project Catalog constraints:
 * - JPG/PNG up to 20 images, each <= 10MB, dimensions <= 4000px
 * - Aspect ratio check against Upwork 4:3 standard (3600×2700 or 1200×900)
 * - Optional MP4 video <= 100MB and <= 90 seconds
 * - Optional PDF documents up to 2 files, <= 2MB each
 */

export async function inspectImageFile(file) {
  const result = {
    fileName: file.name,
    sizeBytes: file.size,
    type: file.type,
    width: 0,
    height: 0,
    aspectRatio: '',
    valid: true,
    errors: [],
    warnings: []
  };

  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (!['jpg', 'jpeg', 'png'].includes(ext)) {
    result.errors.push(`Invalid image format ".${ext}". Upwork only accepts JPG or PNG images.`);
    result.valid = false;
  }

  const MAX_IMAGE_BYTES = 10 * 1024 * 1024; // 10MB
  if (file.size > MAX_IMAGE_BYTES) {
    const mb = (file.size / (1024 * 1024)).toFixed(2);
    result.errors.push(`File size (${mb} MB) exceeds Upwork 10MB limit.`);
    result.valid = false;
  }

  // Inspect dimensions in browser environment
  if (typeof window !== 'undefined' && typeof Image !== 'undefined') {
    try {
      const dimensions = await readImageDimensions(file);
      result.width = dimensions.width;
      result.height = dimensions.height;

      if (dimensions.width > 4000 || dimensions.height > 4000) {
        result.errors.push(`Image dimensions (${dimensions.width}×${dimensions.height}px) exceed Upwork maximum of 4000×4000px.`);
        result.valid = false;
      }

      if (dimensions.height > 0) {
        const ratio = dimensions.width / dimensions.height;
        result.aspectRatio = `${ratio.toFixed(2)}:1`;

        // Upwork standard 4:3 is 1.333
        if (ratio < 1.2 || ratio > 1.45) {
          result.warnings.push(`Aspect ratio is ${result.aspectRatio}. Upwork strongly recommends 4:3 (e.g., 3600×2700 or 1200×900) so your design does not get cropped unexpectedly in search grids.`);
        } else if (dimensions.width < 1000 || dimensions.height < 750) {
          result.warnings.push(`Resolution (${dimensions.width}×${dimensions.height}px) is low. For crisp rendering on retina displays, Upwork recommends at least 1200×900 or master 3600×2700.`);
        }
      }
    } catch (err) {
      result.warnings.push('Could not decode image dimensions in browser: ' + err.message);
    }
  }

  return result;
}

export async function inspectVideoFile(file) {
  const result = {
    fileName: file.name,
    sizeBytes: file.size,
    durationSeconds: 0,
    valid: true,
    errors: [],
    warnings: []
  };

  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (ext !== 'mp4') {
    result.errors.push(`Invalid video format ".${ext}". Upwork requires MP4 video.`);
    result.valid = false;
  }

  const MAX_VIDEO_BYTES = 100 * 1024 * 1024; // 100MB
  if (file.size > MAX_VIDEO_BYTES) {
    const mb = (file.size / (1024 * 1024)).toFixed(1);
    result.errors.push(`Video size (${mb} MB) exceeds Upwork 100MB limit.`);
    result.valid = false;
  }

  if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    try {
      const dur = await readVideoDuration(file);
      result.durationSeconds = Math.round(dur);
      if (result.durationSeconds > 90) {
        result.errors.push(`Video duration (${result.durationSeconds}s) exceeds Upwork strict 90-second limit.`);
        result.valid = false;
      }
    } catch (err) {
      result.warnings.push('Could not read video duration in browser.');
    }
  }

  return result;
}

export function inspectPdfFile(file) {
  const result = {
    fileName: file.name,
    sizeBytes: file.size,
    valid: true,
    errors: [],
    warnings: []
  };

  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (ext !== 'pdf') {
    result.errors.push(`File is not a PDF.`);
    result.valid = false;
  }

  const MAX_PDF_BYTES = 2 * 1024 * 1024; // 2MB
  if (file.size > MAX_PDF_BYTES) {
    const mb = (file.size / (1024 * 1024)).toFixed(2);
    result.errors.push(`PDF size (${mb} MB) exceeds Upwork 2MB limit.`);
    result.valid = false;
  }

  return result;
}

function readImageDimensions(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      URL.revokeObjectURL(url);
      resolve({ width: img.naturalWidth, height: img.naturalHeight });
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load image for inspection'));
    };
    img.src = url;
  });
}

function readVideoDuration(file) {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      URL.revokeObjectURL(url);
      resolve(video.duration);
    };
    video.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Failed to load video metadata'));
    };
    video.src = url;
  });
}

/**
 * Optional Canvas Cover Generator (3600x2700 master PNG)
 * Provided strictly as a fast fallback utility if user has not prepared an image.
 */
export function renderPlaceholderCover(canvas, { title = 'Project Catalog', category = 'Professional Service', theme = 'navy' } = {}) {
  if (!canvas) return;
  canvas.width = 3600;
  canvas.height = 2700;
  const ctx = canvas.getContext('2d');

  // Background
  const themes = {
    navy: { bg1: '#0B192C', bg2: '#1E3E62', accent: '#0084FF', text: '#FFFFFF', sub: '#CBD5E1' },
    slate: { bg1: '#0F172A', bg2: '#334155', accent: '#38BDF8', text: '#FFFFFF', sub: '#94A3B8' },
    emerald: { bg1: '#064E3B', bg2: '#047857', accent: '#34D399', text: '#FFFFFF', sub: '#D1FAE5' }
  };
  const c = themes[theme] || themes.navy;

  const grad = ctx.createLinearGradient(0, 0, 3600, 2700);
  grad.addColorStop(0, c.bg1);
  grad.addColorStop(1, c.bg2);
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 3600, 2700);

  // Decorative border / safe margin guides (safe zone: 10% inset)
  ctx.strokeStyle = c.accent;
  ctx.lineWidth = 12;
  ctx.strokeRect(200, 200, 3200, 2300);

  // Category Tag
  ctx.fillStyle = c.accent;
  ctx.fillRect(360, 400, 800, 90);
  ctx.fillStyle = '#FFFFFF';
  ctx.font = 'bold 44px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  ctx.fillText(category.toUpperCase().slice(0, 32), 400, 460);

  // Main Title (word wrapped within safe area)
  ctx.fillStyle = c.text;
  ctx.font = 'bold 110px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';

  const fullTitle = title.length > 0 ? title : 'Professional Project Catalog Service';
  const words = fullTitle.split(' ');
  let line = '';
  let y = 720;
  const maxLineWidth = 2800;

  for (let n = 0; n < words.length; n++) {
    const testLine = line + words[n] + ' ';
    const metrics = ctx.measureText(testLine);
    if (metrics.width > maxLineWidth && n > 0) {
      ctx.fillText(line, 360, y);
      line = words[n] + ' ';
      y += 140;
    } else {
      line = testLine;
    }
  }
  ctx.fillText(line, 360, y);

  // Footer badge
  ctx.fillStyle = c.sub;
  ctx.font = '52px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  ctx.fillText('Verified 4:3 High-Resolution Master Canvas (3600×2700)', 360, 2320);
}

