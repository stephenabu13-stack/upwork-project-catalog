# Upwork Project Catalog Studio & Content Upload Assistant

A high-performance, locally runnable workspace and Chrome Extension designed to draft, research, optimize, and upload professional **Upwork Project Catalogs** without friction.

---

## 🎯 Core Design: Content & Research Focus (Manual Image Design)

As requested, **the workspace and extension do not force arbitrary AI image generation**. 
- You design your custom cover art in Canva, Figma, or Photoshop (4:3 aspect ratio, e.g. **3600×2700 PNG** or **1200×900**).
- **Dedicated Stored Image Location**: Under Step 3 (Gallery) in the Studio, drop your designed cover. It is saved directly to `uploads/active_cover.png` on your machine.
- **Automated Image Upload to Upwork**: When you reach the Gallery step on Upwork, the assistant automatically retrieves your stored image and uploads it into Upwork's native file input using `DataTransfer`!
- **Direct 1-Click Sync**: Click the **"⚡ Push to Extension"** button in the website topbar or **"Sync with Local Studio"** in the extension popup — no manual JSON downloading/uploading needed.
- The studio and companion extension focus on what takes the most time: **buyer-intent keyword research, high-converting copy generation for all 6 Upwork steps, 1- or 3-tier value ladder pricing, and instant content upload into Upwork**.

---

## 🚀 Quick Start on Windows

### Prerequisites
- **Node.js LTS** (version 22.0.0 or higher).
- **Chrome** browser.
- Zero npm installation required (the foundation uses browser-native JavaScript and Node.js built-ins with zero third-party dependencies).

### 1. Launch the Studio
In your terminal (PowerShell or Command Prompt):
```bash
# Start local server
node server.mjs
# or
npm run dev
```
Open **`http://localhost:4173`** in your browser.

### 2. Run the Automated Test Suite
```bash
npm test
# or
node --test test/*.test.mjs
```
All 13 automated tests verify title character/word boundaries, tag limits, tier pricing ladders, media dimension checks, policy contact guards, and JSON import security.

---

## 🧩 Installing the Chrome Content Upload Extension

The repository includes a Manifest V3 Chrome Extension in the `extension/` folder for one-click content upload directly on Upwork:

1. Open Chrome and navigate to `chrome://extensions/`.
2. Toggle on **Developer mode** in the top-right corner.
3. Click **Load unpacked** in the top-left corner.
4. Select the `extension/` directory inside this project:
   `c:\Users\DELL\Downloads\Upwork project catalog aut\extension`
5. Navigate to Upwork's Project Catalog editor (`https://www.upwork.com/nx/project-catalog/create`).
6. Click the extension icon or the floating assistant widget to **Auto-Fill Step Content** (Title, tags, tiers, requirements, summary description, FAQs) or copy any individual field.
7. Drag your manually designed 3600×2700 cover image directly into Upwork's native gallery box.

---

## 🛠️ Features Overview

### 1. 6-Step Upwork Catalog Data Model
- **Step 1: Overview**:
  - Live preview with automatic Upwork prefix handling (Upwork prepends `"You will get"`, so the studio prevents you from accidentally repeating it).
  - Character counter (max 75 characters) and word counter (minimum 7 words).
  - Category selector with verified category attributes (Brand Identity, WordPress/WooCommerce, SEO, Social Ads, Book Formatting/Beta Reading, and Custom).
  - Upwork search tags (1 to 5 tags, each max 30 characters).
- **Step 2: Pricing & Value Ladder**:
  - 1-tier or 3-tier mode (Starter, Standard, Advanced).
  - Custom tier title (max 30 characters) and description (max 80 characters).
  - Delivery days (1 to 70 days) and revisions configuration.
  - Price bounds ($5 to $500,000 USD) with ascending price checks.
- **Step 3: Gallery (Manual Upload Focus)**:
  - Drag-and-drop file inspector for JPG and PNG images.
  - Automatic inspection of width, height, file size, and aspect ratio.
  - Warnings for non-4:3 aspect ratios that would get cropped in search grids.
  - Verification for optional MP4 video (<= 100MB, <= 90 seconds) and PDFs (<= 2MB each).
  - Optional fallback canvas utility to export a 3600×2700 master PNG if a quick placeholder is needed.
- **Step 4: Requirements**:
  - Tailored buyer onboarding questions (10 to 250 characters).
  - Mandatory flag toggles and answer types (Free text, Multiple choice, File attachment).
- **Step 5: Description & Steps**:
  - Project summary (120 to 1,200 characters) with built-in detection for forbidden off-platform contact details (email, phone, WhatsApp, Telegram, Skype).
  - Project steps (up to 10 steps, title <= 60 chars, description <= 250 chars).
  - Frequently Asked Questions (up to 5 FAQs, question <= 100 chars, answer <= 250 chars).
- **Step 6: Review & Finalize**:
  - Real-time readiness check against Upwork constraints.
  - Legal confirmations (Copyright ownership and Terms of Service agreement).
  - Final publishing checklist for Upwork's official site.

### 2. Dual Generation Engine
1. **Local Template Engine (`src/engine.js`)**:
   - 100% offline, instant generation across all 5 core freelance niches.
   - Zero API key or external credits required.
2. **Optional Google Gemini AI (`/api/generate`)**:
   - Uses server-side `GEMINI_API_KEY` from `.env`.
   - Never exposes API keys in browser JavaScript or client-side storage.
   - Generates fully customized, non-generic copy tailored to custom user briefs.

### 3. SEO & Keyword Intent Research Tool
- Paste raw keywords or search queries.
- Classifies search intent (High Buyer Intent vs Commercial Investigation vs Informational).
- Identifies and applies the top 5 high-converting tags directly to your project overview.

### 4. Data Safety & Export
- LocalStorage persistence with defensive schema validation.
- Binary media bytes are **never** stored in LocalStorage or transmitted over the wire.
- 1-click Export to **JSON** and formatted **Markdown**.
- Secure Import JSON with schema guard that resets legal checkboxes.
- Project duplication and deletion with immediate state refresh.

---

## 🔒 Upwork Terms of Service Compliance

This tool strictly respects Upwork's [Use of Bots and Other Automation](https://support.upwork.com/hc/en-us/articles/43342677368467-Use-bots-and-other-automation-properly) policies:
- **No scraping** of authenticated Upwork pages.
- **No session hijacking**, cookie extraction, or CAPTCHA bypass.
- **No automated form submission**: The local workspace prepares and validates your listing, and the companion extension assists with text entry while you perform the publishing action yourself on Upwork's official website.

---

## 🧪 Verified Test Results

| Test Category | Tested Items | Result |
| :--- | :--- | :--- |
| **Title Constraints** | 75/76 chars, 7-word min, "You will get" prefix prevention | **PASS** |
| **Tag Boundaries** | 1-5 tags, max 30 chars, duplicate prevention | **PASS** |
| **Pricing Rules** | 1 & 3 tiers, $5-$500k range, 1-70 delivery days, max 30/80 chars | **PASS** |
| **Media Inspector** | 10MB JPG/PNG limit, 4000px limit, 4:3 ratio, 90s MP4, 2MB PDF | **PASS** |
| **Content Integrity** | 120-1200 chars summary, off-platform contact detection | **PASS** |
| **Security & Schema** | Malformed JSON rejection, legal reset on import | **PASS** |
| **Server & Endpoints** | Static root `/`, `/specs/categories.json`, `/api/health`, 503 fallback | **PASS** |

